import Vue from 'vue'
import toast from '@/components/toast'

Vue.component('toast', toast)