<template>
  <div>
    <div class="a-box encapsulating-div container text-justify">
      <div class="a-box-inner">
        <div class="a-box header_logo_desk">
          <div class="a-box-inner">
           <div style="display: flex;
    align-items: center;">
          <a href="https://www.wenslink.com">
              <img
                src="~static/icons/logo.png"
                style="height: 75px;padding-bottom: 10px; object-fit:contain"
                class="company_logo"
              />
          </a>
              <!-- <h4 style="padding-left: 10px" class="margin-top-10">WENSLink </h4> -->
            </div>
          </div>
        </div>

        <div class="a-box seller_message_box">
          <div class="a-box-inner">
            <h1>Seller Agreement</h1>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Merchant Terms of Use under WENSLink .com:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}"> 
This report is an electronic record as far as Information Technology Act, 2000 ("IT Act, 2000"), the relevant principles there under and the arrangements relating to electronic records in different rules as altered by the Information Technology Act, 2000. This electronic record is created by a PC framework and does not require any physical or computerized marks. 
This report is distributed as per the arrangements of Rule 3 (1) of the Information Technology (Intermediaries Guidelines) Rules, 2011 that require distributing the principles and guidelines, security approach and Terms of Use for access to or utilization of www.WENSLink .com site. 
The area name www.WENSLink .com, including the related versatile website and portable application just as the merchant entry seller.wenslink.com (hereinafter alluded to as "Stage") is claimed and worked by WENSLINK  Private Limited  (hereinafter alluded to as 'WENSLINK '), an organization joined under the Companies Act, 1956, with its enrolled office at House No. 13A, ByeLane- 11, Milan Path, Zoo Road Tiniali, Guwahati, Dist.- Kamrup Metro, Assam, PIN- 781024 IN
With the end goal of the Terms of Use (hereinafter alluded to as "ToU"), any place the specific circumstance so requires, 'you' and 'your' will identify with any common or legitimate individual who has consented to turn into a vendor on the Platform by giving enlistment information while enrolling on the Platform utilizing PC frameworks. The word 'client' will be on the whole suggest a merchant, a purchaser, and any guest on the Platform and the terms 'we', 'us' and 'our' will mean WENSLINK . 
Your utilization of the Platform and the highlights in that is administered by the accompanying terms and conditions (ToU) including material approaches accessible on the Platform, notices and correspondences sent to you on the Platform which are joined thus by method for reference. In the event that you execute on the Platform, you will be liable to the strategies that are pertinent to the platform for such an exchange. By simple utilization of the platform you will contract with WENSLINK , and these terms and conditions including the arrangements establish your coupling commitments to WENSLINK . 
When you utilize any present or future administrations given by us through the platform you will be liable to the standards, rules, strategies, terms and conditions appropriate to such administrations and they will be esteemed consolidated into the ToU and thought about a vital part of the ToU. We save the right, at our sole prudence, to change, alter, include, or evacuate bits of the ToU whenever. We will advise you through any of the correspondence modes as referenced in this ToU if there should be an occurrence of any progressions or updates to the ToU that tangibly sway your utilization of the platform. Your proceeded with utilization of the platform following the progressions or updates will imply that you acknowledge and consent to the modifications. For whatever length of time that you consent to the ToU, we award you an individual, non-elite, non-transferable, and constrained benefit to enter and utilize the Platform. 

Getting to, browsing, or otherwise using the platform indicates your agreement with all the terms and conditions under the ToU. If it's not too much trouble read the tou carefully before proceeding. By impliedly or explicitly tolerating the ToU, you likewise acknowledge and consent to be bound by the majority of WENSLINK 's strategies pertinent to you, as corrected, now and again. 
</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Merchant Eligibility:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">The utilization of the Platform is accessible just to people who can shape lawfully restricting contracts under the Indian Contract Act, 1872. People who are "inept to contract" inside the importance of the Indian Contract Act, 1872 including minors, un-released insolvents and so forth are not qualified to utilize the Platform. In the event that you are a minor for example younger than 18 years, you will not enlist as a merchant on the Platform, execute or utilize the Platform. WENSLINK  claims all authority to end your enrollment or potentially deny you access to the Platform in the event that it is brought to WENSLINK 's notice or found that you are younger than 18 years. In the event that you register as a business element, you speak to that you are appropriately approved by the business element to acknowledge the ToU and you have the expert to tie the business element to the ToU. 
</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Your Account and Registration Obligations:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">Over the span of your utilization of the Platform, you consent to outfit your subtleties and data as mentioned by us now and again. You will stay in charge of keeping up classification of this data, just as your presentation name, login and secret word subtleties. You concur that on the off chance that you give any data which is false, incorrect, not current, or deficient or we have sensible grounds to speculate that such data is false, off base, not current, inadequate, or not as per the ToU, we will reserve the option to suspend or end your record on the Platform or uncertainly square you from getting to the Platform. 
</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Record and Registration Obligations:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">All through your use of the Platform, you agree to equip your nuances and information as referenced by us from time to time. You will remain responsible for keeping up mystery of this information, similarly as your introduction name, login and mystery express nuances. You agree that in case you give any information which is false, wrong, not current, or insufficient or we have reasonable grounds to assume that such information is false, inaccurate, not current, divided, or not according to the ToU, we will hold the benefit to suspend or end your record on the Platform or uncertainly square you from getting to the Platform. 
</p>
          </div>
        </div>
         <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Correspondences:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">When you utilize the Platform or send messages, other information, data, or correspondence to us, you concur and comprehend that you are speaking with us through electronic records and you agree to get interchanges by means of electronic records from us occasionally or as and when required. We may speak with you by email or some other method of correspondence, electronic or something else. 
</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Stage for Transaction and Communication:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">The Platform is a stage that clients use to autonomously meet and collaborate with each other for their exchanges. WENSLINK  isn't and can't be involved with any exchange or debate between clients on the Platform. 
Thus: 
1. 	All business/authoritative terms are offered by you and settled upon among you and purchasers alone. The business/legally binding terms incorporate (without restriction) value, shipping costs, installment techniques and terms, date, period, and method of conveyance, and guarantees and after-deals administrations identified with items and administrations. WENSLINK  does not decide, guidance, have any control, or in any capacity include itself in the offering or acknowledgment of such business/legally binding terms among you and purchasers. 
2. 	WENSLINK  does not make any portrayals or guarantees with respect to particulars, (for example, quality, worth, and saleability) of the items or administration’s proposed to be sold, offered to be sold or bought on the Platform. WENSLINK  does not certainly or unequivocally support or embrace the deal or buy of any items and administrations on the Platform. WENSLINK  acknowledges no obligation for any mistakes or exclusions of outsiders in connection to the items and administrations. 
3. 	WENSLINK  isn't in charge of any non-execution or break of any agreement among you and purchasers. WENSLINK  can't and does not ensure that you and purchasers concerned will perform transaction(s) finished up on the Platform. WENSLINK  will not and isn't required to intercede or resolve questions or contradictions among you and purchasers. 
4. 	WENSLINK  does not make any portrayals or guarantees with respect to thing particulars, (for example, lawful title, financial soundness, character, and so on.) of any of its clients. You are encouraged to autonomously check the bona fides of a specific purchaser you manage on the Platform and utilize your best judgment in such manner. 
5. 	WENSLINK  does not anytime during an exchange among you and a purchaser on the Platform come into or claim any of the items or administrations offered by you, gain title to or have any rights or claims over the items or administrations offered by you to the purchaser. 
6. 	At no time will WENSLINK  hold any right/title to or enthusiasm for the things nor have any commitments or liabilities as for such an agreement. WENSLINK  isn't in charge of unsuitable or postponed execution of administrations, harms, or deferrals because of things which are out of stock, inaccessible, or delay purchased. 
7. 	The Platform is just a stage that can be used by you to arrive at a bigger client base to sell things or administrations. WENSLINK  just gives a stage to correspondence and it is concurred that the agreement available to be purchased of any items or administrations will be a carefully bipartite contract among you and the purchaser. 

8. 	You discharge and repay WENSLINK  as well as any of its officials and delegates from any cost, harm, obligation or other result of any of the activities of the clients on the Platform and explicitly postpone any cases that you may have for this sake under any appropriate law. Despite its sensible endeavors for that benefit, WENSLINK  can't control the data.

</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Utilization of the Platform:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">You concur and comprehend that WENSLINK  and the Platform simply give facilitating administrations to its enlisted clients and people perusing/visiting the Platform. All things promoted/recorded and the substance in that are publicized and recorded by enrolled clients and are outsider client created substance. WENSLINK  will bear no obligation or risk in connection to or emerging out of outsider client produced content. WENSLINK  neither begins nor starts the transmission nor chooses the sender and collector of the transmission nor chooses nor adjusts the data contained in the transmission. WENSLINK  is only a delegate and does not meddle in the exchange among purchasers and dealers. 
You concur, embrace and affirm that your utilization of the Platform will be carefully administered by the accompanying restricting standards: 
1. 	You will not have, show, transfer, adjust, distribute, transmit, update or offer any data or picture which: 
(a) 	Has a place with someone else and over which you have no right; 
(b) 	Is horribly hurtful, bothering, ungodly, slanderous, extremism, foul, explicit, paedophilic, hostile, intrusive of another's protection, derisive, or racially, ethnically questionable, deriding, identifying with or empowering illegal tax avoidance or betting, or generally unlawful in any way whatever, or unlawfully compromising or hassling, including yet not constrained to 'obscene portrayal of ladies' inside the significance of the Indecent Representation of Women (Prohibition) Act, 1986; 
(c) 	Is false, off base or deluding in any capacity; 
(d) 	Is evidently hostile to the online network, for example, explicitly unequivocal substance or substance that advances profanity, pedophilia, prejudice, fanaticism, scorn, or physical mischief of any sort against any gathering or person; 
(e) 	Hassles or promoters badgering of someone else; 
(f) 	Includes the transmission of 'garbage mail', 'junk letters', spontaneous mass mailing, or 'spamming'; 
(g) 	Advances criminal behavior or direct that is harsh, undermining, revolting, slanderous, or derogatory; 
(h) 	Encroaches upon or damages any outsider's privileges [including however not restricted to protected innovation rights, privileges of security (counting without constraint unapproved revelation of an individual's name, email address, physical location, or telephone number) or privileges of publicity]; 
(I) 	Advances an unlawful or unapproved duplicate of someone else's copyrighted work (see "Copyright grievance" beneath for directions on the most proficient method to hold up an objection about transferred copyrighted material, for example, giving pilfered PC projects or connections, data to go around maker introduced duplicate ensure gadgets, or pilfered music or connections to pilfered music documents; 
(j) 	Contains limited or secret key just access pages, shrouded pages or pictures or URLs prompting some other pages (those not connected to or from another open page); 
(k) 	Gives material that adventures individuals in a sexual, brutal or generally unseemly way or requests individual data from anybody; 
(l) 	Gives instructional data about criminal operations, for example, making or purchasing unlawful weapons, damaging somebody's protection, giving or making PC infections; 
(m) 	Contains unapproved recordings, photos or pictures of someone else (regardless of whether a minor or a grown-up); 
(n) 	Attempts to increase unapproved get to or surpasses the extent of approved access to the Platform, profiles, online journals, networks, account data, notices, companion demands, or different zones of the Platform, or requests passwords or individual recognizing data for business or unlawful purposes from different clients on the Platform; 
(o)	Takes part in business exercises as well as deals, for example, challenges, sweepstakes, deal, promoting, fraudulent business models, or the purchasing or selling of 'virtual' things identified with the Platform without our earlier composed assent. 
All through the ToU, WENSLINK 's earlier composed assent implies a correspondence originating from WENSLINK 's Legal Department because of your solicitation and explicitly tending to the exercises or lead for which you have looked for approval; 
(p) 	Requests betting or takes part in any betting movement which we, at our sole carefulness, accept is or could be translated as being unlawful; 
(q) 	Meddles with another's utilization and happiness regarding the Platform; 
(r) 	Alludes to any site/URL which, at our sole attentiveness, contains material that is wrong for the Platform or some other site and substance that is disallowed or abuses the letter and soul of ToU; 
(s) 	Hurts minors in any capacity; 
(t) 	Encroaches any patent, trademark, copyright, restrictive rights, outsider's competitive innovations, privileges of attention, or protection, is fake, or includes the closeout of fake or taken things; 
(u) 	Abuses any law until further notice in power; 
(v)	 Tricks or misdirects the recipient/clients about the starting point of messages or imparts any data which is horribly hostile or threatening in nature; 
(w)	Mimics someone else; 
(x) 	Contains programming infections or some other PC codes, records, or projects intended to intrude on, devastate, or limit the usefulness of any PC asset; or contains any trojan ponies, worms, time bombs, cancelbots, easter eggs, or other PC programming schedules that may harm, adversely meddle with, lessen estimation of, secretly block, or dispossess any framework, information, or individual data; 
(y) 	undermines the solidarity, trustworthiness, safeguard, security or sway of India, amicable relations with remote states, or open request or makes induction the commission of any offense or forestalls examination of any offense or is offending some other country; 
(z) 	Will, legitimately or by implication, offer or endeavor to offer exchange or endeavor to exchange anything which is precluded or confined in any way under the arrangements of any relevant law, principle, guideline or rule for the present in power; 
(aa) 	will make risk for us or cause us to lose (in entire or part) the administrations of our Internet Service Provider ("ISPs") or different providers. 
2. 	You will not utilize any 'profound connection', 'page-scratch', 'robot', 'insect', programmed gadget, program, calculation, technique, or any comparable or proportional manual procedure to get to, procure, duplicate, screen any part of the Platform or content or in any capacity recreate, or go around the navigational structure, introduction of the Platform, or any substance to acquire or endeavor to get any material, records, or data through any methods not deliberately made accessible through the Platform. We claim our authority to bar any such exercises. 
3. 	You will not endeavor to increase unapproved access to any bit or highlight of the Platform, different frameworks, systems associated with the Platform, server, PC, arrange, or the administrations offered on or through the Platform by hacking, secret key 'mining', or some other ill-conceived implies. 
4. 	You will not test, output or test the powerlessness of the Platform or any system associated with the Platform or break the security, verification measures on the Platform or any system associated with the Platform. You may not turn around look-into, follow or try to follow data on some other client of or guest to Platform (counting any record on the Platform that isn't claimed by you) or to its source or endeavor the Platform, any administration, data made accessible, or offered by or through the Platform in any capacity where the reason for existing is to uncover any data (counting however not restricted to individual recognizable proof or data other than your own data) given by the Platform. 
5. 	You will not make any negative, slandering, or abusive statement(s)/comment(s) about us, the brand name or space name utilized by us, including the terms WENSLINK , Flipcart, WENSLink .com or generally take part in any direct or activity that may discolor the picture or notoriety of WENSLINK  or merchants on the stage or generally discolor or weaken any WENSLINK  exchange mark, administration marks, exchange name and additionally generosity related with such exchange, administration checks or exchange name as might be claimed or utilized by us. You concur that you won't make any move that forces an irrational or excessively enormous burden on the framework of the Platform or WENSLINK 's frameworks, systems, or any frameworks or systems associated with WENSLINK .
6. 	You make a deal to avoid utilizing any gadget, programming or routine to meddle or endeavor to meddle with the correct working of the Platform, any exchange being directed on the Platform or some other individual's utilization of the Platform. 
7. 	You will not produce headers or generally control identifiers so as to mask the root of any message, transmittal you send to us on or through the Platform, or any administration offered on or through the Platform. You may not imagine that you are or speak to another person or imitate some other individual or element. 
8. 	You may not utilize the Platform or any substance for any reason that is unlawful or restricted by the ToU or to request the presentation of any criminal behavior or other action which encroaches the privileges of WENSLINK  or potentially others. 
9. 	You will consistently guarantee full consistence with the pertinent arrangements of the Information Technology Act, 2000, and the guidelines thereunder as material and revised every now and then and furthermore all appropriate residential laws, principles and guidelines (counting the arrangements of any pertinent Exchange Control Laws or Regulations in power) and International Laws, Foreign Exchange Laws, Statutes, Ordinances and Regulations (counting, however not constrained to Integrated Goods and Services Tax Act, Central Goods and Services Tax Act, Food Safety and Standards Authority of India (FSSAI), significant State Goods and Services Tax Act or Union Territories Goods and Services Tax Act and Custom Duty, Local Levies as might be relevant) and get the fundamental licenses and allows in regards to your utilization of our Platform, administration or potentially instruments and your posting, buy, requesting of offers to buy, and clearance of things or administrations. You will not take part in any exchange in a thing or administration, which is precluded by the arrangements of any appropriate law including trade control laws or guidelines for the present in power. Specifically you will guarantee that if any of your things recorded on the Platform qualifies as an "Artifact" or "Workmanship treasure" as characterized in the Act ("Artwork"), you will demonstrate that such Artwork is "non-exportable" and offered subject to the arrangements of the Antiquities and Art Treasures Act, 1972, and will guarantee that it isn't conveyed to any purchaser at wherever outside India. 
10. 	You will carefully conform to the WENSLINK  Group OFAC Policy (Trade Compliance Policy Statement) as might be corrected every now and then. The surviving Trade Compliance Policy Statement is accessible at the Seller Learning Center. 
11. 	Exclusively to empower us to utilize the data you give us thus that we don't abuse any rights you may have in your data, you consent to concede us a non-elite, around the world, ceaseless, unavoidable, eminence free, and sub-licensable (through numerous levels) appropriate to practice the copyright, attention or database rights or some other rights you have in your data for any present or future limited time or promoting related exercises and any business reasons for WENSLINK . We will just utilize your data as per this ToU and our Privacy Policy. 
12. 	Now and again you will be in charge of giving data identifying with the things or administrations proposed to be sold by you. In this association, you attempt that all such data will be precise in all regards. You will not overstate or over underline the qualities of such things or administrations to delude different clients on the Platform in any way. 
13. 	You will not take part in promoting or sales of different venders on the Platform to purchase or sell any items or administrations, including yet not constrained to items or administrations identified with what is shown on the Platform. You may not transmit any networking letters or spontaneous business or garbage email to different clients gained/by means of the Platform. It will be an infringement of the ToU to utilize any data acquired from the Platform so as to bother, misuse, or damage others or contact, publicize and offer to or request people other than the individuals who have purchased from you. You comprehend that we have the privilege consistently to uncover any data (counting the character of the people who have given data or material on the Platform) as important to fulfill any law, guideline, or substantial administrative solicitation. This may incorporate, without constraint, divulgence of the data regarding the examination of a supposed criminal behavior or its requesting as well as reaction to a legal court request or subpoena. Moreover, we can (and you thus explicitly approved us to) unveil any data about you to law authorization or other government authorities as we, at our sole caution, esteem important or fitting regarding the examination as well as goals of potential violations, particularly those that may include individual damage. We hold the right, however have no commitment, to screen the material posted on the Platform. WENSLINK  will have the right, at its sole tact, to evacuate any substance that abuses or is claimed to damage any relevant law or either the soul or letter of the ToU. Despite this right, YOU REMAIN EXCLUSIVELY IN CHARGE OF THE SUBSTANCE OF THE MATERIAL YOU POST ON THE SITE AND YOUR FREE CORRESPONDENCE WITH THE PURCHASERS AND DIFFERENT DEALERS, PAYING LITTLE RESPECT TO SHAPE. It would be ideal if you be prompted that such substance posted does not mirror WENSLINK 's perspectives. In no occasion will WENSLINK  expect or have any obligation or risk for any substance posted on the Platform or cases, harms, or misfortunes coming about because of its utilization as well as appearance of it on the Platform. You thusly speak to and warrant that you have fundamental rights to all the substance you give and all data it contains and that such substance will not encroach any restrictive or different privileges of outsiders or contain any deceptive, offensive, tortious, or generally unlawful data. 
14. 	Your correspondence or business dealings with or investment in the advancement of publicists on or through the Platform (counting installment and conveyance of related items or administrations, some other terms, conditions, guarantees, or portrayals related with such dealings) are exclusively among you and such promoters. We will not be capable or subject for any misfortune or harm of any kind brought about because of such dealings or the nearness of such publicists on the Platform. 
15. 	It is conceivable that different clients (counting unapproved people or 'programmers') may post or transmit hostile or profane material on the Platform and that you might be automatically presented to such material. It is additionally feasible for others to get individual data about you because of your utilization of the Platform and utilize such data to bug or harm you. We don't endorse of such unapproved utilizes however by utilizing the Platform, you recognize and concur that we are not in charge of the utilization of any close to home data that you freely unveil or share with others on the Platform. It would be ideal if you cautiously select the kind of data that you freely reveal or share with others on the Platform. 

16. 	WENSLINK  will have every one of the rights to make fundamental move and guarantee harms that may happen because of your association/interest in any capacity all alone or through group(s) of individuals, purposefully or inadvertently, in DoS (forswearing of administration)/DDoS (Distributed Denial of Services). 

</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Selling:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">As an enlisted vender, you will list item(s) available to be purchased on the Platform as per the strategies which are consolidated by method for reference in this ToU. You should be lawfully ready to sell the item(s) you list available to be purchased on our Platform and must have all the essential licenses and allows required for such deal. You should guarantee that the recorded things don't encroach upon the protected innovation, competitive innovation or other exclusive rights or privileges of exposure or security privileges of outsiders. Postings may just incorporate content depictions, illustrations, pictures or recordings that portray your thing available to be purchased. All things must be recorded in a suitable classification on the Platform. Every single recorded thing must be kept in stock for effective satisfaction of offers. The posting portrayal of the thing must not be deceiving and should depict real state of the item. On the off chance that the thing depiction does not coordinate the genuine state of the thing, you consent to discount any sum that you may have gotten from the purchaser. You make a deal to avoid posting a solitary item in different amounts crosswise over different classifications on the Platform. WENSLINK  maintains all authority to erase such numerous postings of a similar item recorded by you in different classifications. WENSLINK  maintains whatever authority is needed to limit the selling of items starting from specific nations. 
For Food and Nutrition class, vender will stick to the base equalization time span of usability standards as gave at the connection here 
Consistence on selling of products/administrations 
You will likewise guarantee full consistence with the arrangements of Integrated Goods and Services Tax (IGST), Central Goods and Services Tax (CGST) and Union Territory Goods and Services Tax (UTGST) or State Goods and Services Tax (SGST) in regard of the products/administrations provided by you. 
It is your duty to charge fitting merchandise and enterprises imposes on the provisions affected and settlement of the equivalent to the Government. WENSLINK will not be in charge of any lack as well as oversight on your part. 
As per the duty accumulation at source arrangements under IGST, CGST and/UTGST or SGST, the gateway would gather charge gathering at source at material rates on net estimation of assessable supplies made through the entrance and transmit to the fitting Government. 
In the event of any befuddles by virtue of assessment accumulation at source, you will be required to give all pertinent data to WENSLINK  to compare with the important specialists and furthermore if there should arise an occurrence of any risk gathering by virtue of oversight will be your commitment to pay such shortage.
You will be required to give the relating Harmonized System Nomenclature (HSN) code number for each item posting. If you don't give the HSN code number that specific item will be delisted and you will never again have the option to sell the item on our foundation. 
You will likewise be required to give your GSTIN, without which we won't probably raise a receipt on you. If you don't give your GSTIN number, exchange for you will be blocked and requests won't be prepared for you. In case of you giving your Input Service Distributor Registration Number, WENSLINK  would be issuing a receipt to the ISD GST enrollment number as outfitted by you. It is your duty to embrace the vital consistence required in regard of the said ISD enrollment number. 
In case of any contention between the conditions of this proviso and some other statement in these terms of utilization, the arrangements of this condition will win. 
You concur and attempt that You will not, whenever, buy over 25% of your stock (as far as annualized esteem in a monetary year), indicated to be sold on the Platform, from WENSLINK or its Group Companies. Gathering Company will have the importance according to the surviving Foreign Direct Investment Policy of India. We may expect you to give affirmation (counting examiners authentication) to affirm consistence with this prerequisite. 
We don't command that any of your Products ought to be sold solely on the Platform. For lucidity, successful February 01, 2019, WENSLINK singularly postpones any commitment on You to sell solely on the Platform. Any composed or oral courses of action unexpectedly, will stand singularly postponed. 

</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Substance Posted on the Platform:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">All content, illustrations, merchant interfaces, visual interfaces, photos, trademarks, logos, sounds, music and fine art, notes, messages, messages, announcement postings, drawings, profiles, feelings, thoughts, pictures, recordings, sound documents, other material or data (all in all 'Content') are outsider produced Content and WENSLINK has no obligation or risk over such outsider created Content as WENSLINK is just a middle person for the reasons for this ToU. Aside from as explicitly gave in the ToU, no piece of the Platform including the Content might be duplicated, recreated, republished, transferred, posted, openly showed, encoded, interpreted, transmitted or conveyed in any capacity (counting 'reflecting') to some other PC, server, site or other mode for production, dissemination or any business venture without WENSLINK 's earlier composed assent. 
You may utilize the data on the items and administrations made accessible on the Platform for downloading gave you: 
(1) 	Don’t evacuate any restrictive notice language in all duplicates of such Content; 
(2) 	Utilize such Content just for your own, non-business instructive reason and don't duplicate or post such data on any organized PC or communicate it to any media; 
(3) 	Make no changes to any Content; and 
(4) 	Don’t make any extra portrayals or guarantees identifying with the Content. 

You will be in charge of the Content posted or transmitted on the Platform by You. The Content will turn into our property and you award us the around the world, ceaseless, sovereignty free and transferable rights in such content. We will be qualified for, predictable with our protection arrangement as embraced as per pertinent law, utilize the Content or any of its components for a reason everlastingly, including, yet not constrained to, limited time and promoting purposes in any media, regardless of whether presently known or from this point forward concocted or the formation of subsidiary work. You concur that any substance you post might be utilized by us, reliable with this TOU, and you are not qualified for any installment or other pay for such use. 
</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Constrained License:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">WENSLINK  awards merchant a constrained, non-transferable, non-selective, non-sub licensable, non-assignable and individual permit to utilize "Controlled by WENSLINK " and additionally "WENSLink .com" name as well as logo on dealer's receipt for exchanges closed on the Platform. Further, WENSLINK  awards dealer a constrained, non-transferable, non-selective, non-sublicensable, non-assignable and individual permit to utilize "WENSLink .com" name and additionally logo on pressing material utilized by merchant for conveyance of Products sold on the Platform. 
</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Sorts of Sellers:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">Every enrolled merchant are sorted into following levels: 
•	Gold 
•	Silver 
•	Bronze 
This is done premise following criteria:
•	Sales accomplished by dealers (incomes and units) 
•	Fulfillment experience gave to clients (breaks and undoings) 
•	Percentage of nearby/zonal shipment out of your general shipment 
•	Percentage of in general shipments provided in a similar zone to clients by the merchant 
•	Customer criticism against the items sold by such venders (returns and appraisals), and so forth. 
The edges for every one of these criteria are straightforwardly recorded on https://seller.wenslink.com. Premise the level; venders get advantages including the accompanying: 
•	Rebate in commissions and transporting charges and so forth. 
•	Account the executives support 
•	Faster installments 

WENSLINK  maintains whatever authority is needed to reconsider the classifications, criteria, and advantages to advance solid challenge among the dealers so their exhibition lead to better client experience on the Platform. 
</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Installment:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">1. 	Exchanges, exchange cost and every business term, for example, conveyance, dispatch of items and additionally administrations are according to head to head bipartite legally binding commitments among venders and purchasers and the installment office is only utilized by dealers and purchasers to encourage the consummation of exchanges. Utilization of the installment office will not render WENSLINK  obligated or in charge of non–conveyance, non-receipt, non-installment, harm, rupture of portrayals and guarantees, non-arrangement of after-deals or guarantee administrations or extortion as respects the items as well as administrations recorded on the Platform. 
2. 	You have explicitly approved WENSLINK or its specialist co-ops to gather, process, encourage, and transmit installments and additionally the exchange cost electronically or through money down (CoD) to and from purchasers in regard of exchanges through installment office. Your association with WENSLINK is on a head to head premise and by tolerating the ToU, you concur that WENSLINK is a self employed entity for all reasons and does not have control of or obligation for the items or administrations that are recorded on the Platform and paid for by utilizing the installment office. WENSLINK does not ensure the personality of any User nor does it guarantee that a purchaser or a dealer will finish an exchange. 
3. 	You comprehend, acknowledge, and concur that the installment office given by WENSLINK is neither a banking nor budgetary administration, yet simply a facilitator giving an electronic, computerized online electronic installment office for getting installment, or money down (CoD) installment, gathering and settlement for exchanges on the Platform utilizing the current approved financial foundation and Mastercard installment portal (PG) organize. Further, by giving installment office, WENSLINK neither goes about as a trustee nor guardian regarding exchange or exchange cost. 
It is therefore explained that money down (COD) alternative may not be accessible for select items or classifications, at WENSLINK’s sole caution.
4. 	All online bank moves from substantial financial balances are handled utilizing the entryway given by the separate issuing bank that supports installment office to give these administrations to the clients. All such online bank moves on installment office are additionally administered by the terms and conditions consented to between a dealer purchaser and the separate issuing bank. 
</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Dispatch of items or potentially benefits</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}"> 
1. 	You, as a merchant, will be required to dispatch the items as well as administrations for each exchange to the purchaser inside the time span as gave in the TOU to guarantee that the items or potentially administrations are conveyed in an opportune way. Further, you will exclusively be in charge of undertaking travel protection for items sold by You on the Platform. For evasion of uncertainty, WENSLINK won’t be in charge of undertaking any insurance(s) for items sold by dealers on the Platform
2. 	Vender will give dispatch subtleties and subtleties of after-deals administrations identified with items and administrations recorded by it on the Platform to WENSLINK in such a way and inside a time span as gave in the approaches, bombing which the exchange will stand dropped. 
3. 	Merchant will dispatch the items as well as administrations utilizing just an affirmed conveyance channel which gives suitable 'verification of dispatch' and 'confirmation of conveyance' (PoDs) documentation. Such PoD documentation identifying with conveyance ought to be kept up by a vender for a time of 3 (three) years from the date of dispatch. The PoDs ought to be outfitted to WENSLINK on interest inside the time span as told now and again. 
4. 	Merchant concurs that the dispatch subtleties will be valid, right, and properly approved and will not be misdirecting, fake, false, unapproved, unlawful and will not contain any deception of certainties. 
5. 	In the event that a merchant neglects to give dispatch subtleties or furnishes dispatch subtleties not consenting to strategies, it will bring about outcomes as more explicitly expressed in the TOU and may prompt suspension or potentially end of vender account. 
6. 	Vender concurs that the exchange cost paid by a purchaser will be transmitted to a dealer's ledger dependent upon the accompanying occasions: 
a) 	Buyer affirms the conveyance of items or potentially benefits in the exchange; 
b) 	Buyer does not make any move on installment office to affirm conveyance inside such a time span as gave in the approaches in spite of affirmation of dispatch of items as well as administrations by a merchant to the purchaser; 
c) 	Buyer's discount case is dismissed by WENSLINK because of any rupture of the ToU, strategies, and any material law; 
d) 	Settlements to a dealer for effective exchanges under the installment office, barring CoD exchanges, would be in consistence with bearings issued by the Reserve Bank of India (RBI) for opening and activity of records and settlement of installments for electronic installment exchanges including middle people vide its notice RBI/200910/231DPSS.CO.PD.No.1102/02.14.08/200910 dated November 24, 2009 ('RBI Intermediary Guidelines"). According to the RBI Intermediary Guidelines, installments to venders which don't include move of assets to nodal banks will be affected inside a limit of T+2 settlement cycle (where T is characterized as the day of implication with respect to the fruition of exchange) ("Master Settlement Date"). Finish of the exchange will be characterized as pursues:
        <table class="table mt-3">
          <thead class="thead-dark">
            <tr>
            <td>
              <p>
                Particulars
              </p>
            </td>
            <td>
              <p>
                Thresholds (in days)
              </p>
            </td>
            </tr>
          </thead>
          <tbody>
          <tr>
            <td>
              <p>
                Order Date to Dispatch Date
              </p>
            </td>
            <td>
              <p>
                3 Working Day
              </p>
            </td>
          </tr>
          <tr>
            <td>
              Dispatch Date to Delivered Date
            </td>
            <td>
              15 Working Days
            </td>
          </tr>
          <tr>
            <td>
              Return Policy
            </td>
            <td>
              Return Policy	30 Working Days (As per seller policy)
            </td>
          </tr>
          <tr>
            <td>
              Return Req Date to Return Completed Date
            </td>
            <td>
              17 Working Days (As per seller policy)
            </td>
          </tr>
          <tr>
            <td>
              Completion of the transaction
            </td>
            <td>
              15 working days after return policy
            </td>
          </tr>
          </tbody>
        </table>
        WENSLINK may, at its sole watchfulness settle the installment to the venders prior, as per the Payment Settlement Policy. Be that as it may, in case of a contention between the Master Settlement Date and the dates set out in the Payment Settlement Policy, the Master Settlement Date will win. 
7. 	You are required to course all shipments/transfers through the Logistic Partner, except if generally indicated. 'Strategic Partner' will mean a calculated specialist co-op as affirmed by WENSLINK. Prepaid Payment Instruments 
WENSLINK may, either itself or through outsider specialist co-ops, offer prepaid instruments as an installment choice for exchanges on the Platform to clients. Any buys by purchasers on the Platform utilizing the prepaid instruments will be administered by the accompanying terms and conditions: 
I.	Such prepaid instruments might be utilized to make installments for the items and additionally administrations acquired on the Platform.
II.	Such prepaid instruments can be recovered by purchasers by choosing the installment mode as might be given on the Platform. 
III.	Such prepaid instruments can't be utilized to buy other prepaid instruments or blessing vouchers. 
IV.	If the request worth surpasses the measure of such prepaid instruments, the parity must be paid by the particular purchaser by means of Credit Card/Debit Card/Internet Banking. COD will not be accessible as installment choice for such exchanges. 
V.	If the request worth is not exactly the measure of such prepaid instruments, the extraordinary parity (after derivation of request esteem) will reflect as credit balance for such prepaid instruments. 
VI.	Prepaid instruments and any unused equalization of such prepaid instruments will terminate 1 year from the date of their issue. 
VII.	Prepaid instruments can't be recovered for money. 
VIII.	WENSLINK isn’t mindful if prepaid instruments are lost, taken, or utilized without authorization. 
IX.	Buyers can consolidate and utilize a limit of 3 prepaid instruments for every request. They can be joined with special codes. 
X.	Purchases of prepaid instruments are not qualified for cashback offers. 
XI.	All merchants on the Platform will acknowledge this prepaid instrument as an installment instrument. 
XII.	WENSLINK will make installments to merchants whose items or potentially administrations have been bought by purchasers recovering electronic blessing vouchers (EGV) according to the rules issued by the Reserve Bank of India now and again. 

            </p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Charges:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}"> Enlistment on the Platform is free*. WENSLINK does not charge any expense for perusing/enlisting on the Platform. Be that as it may, before you list an item or administration available to be purchased through the Platform, we demand you to survey our expense strategy, which is thus joined by reference into this ToU. WENSLINK maintains whatever authority is needed to change its charge strategy every once in a while. Specifically, WENSLINK may, at its sole carefulness, present new benefits and change a few or the majority of the current administrations offered on the Platform. WENSLink can change/ modify the cost of any product depending on the ongoing market environment. In such an occasion, WENSLINK maintains all authority to present charges for the new administrations offered or alter/present expenses for existing administrations, by and large. Changes to the expense arrangement will be posted on the Platform and such changes will consequently wind up taking effect right now after they are posted on the Platform. Except if generally expressed, all charges will be cited in Indian Rupees (INR) and payable to WENSLINK. You will be exclusively in charge of consistence with every single appropriate law for making installments to WENSLINK. You thus concur that WENSLINK will reserve the privilege to set off any sums due and payable by you to WENSLINK against any installments due from WENSLINK to You. 
Whatever the commission amount raised by our empanelled courier partner levied on CoD will be borne by the seller.
GST/Taxes: You are in charge of paying all expenses related with the utilization of the Platform and charges gathered in regard of such use. You consent to tolerate all appropriate assessments, charges, cesses required subsequently (counting CGST+SGST/IGST/CGST+UGST and GST cess as might be relevant to the exchange). 
1. 	A merchant concurs that WENSLINK may offer to give express settlement to qualified venders according to installments settlement strategy. Express Remittance will be liable to RBI Intermediary Guidelines and game plans/bearings of the nodal bank. WENSLINK, at its sole carefulness, may make such an idea to qualified dealers and the equivalent will not be translated as a privilege however just as a benefit. Qualified merchants comprehend that WENSLINK claims all authority to pull back Express Remittance whenever for any infringement of the ToU or WENSLINK’s arrangements and additionally disappointment by the qualified venders to keep up or conform to the parameters as might be chosen by WENSLINK every now and then. 
2. 	Receipt age: A vender explicitly concurs that issuing right and complete receipt is the sole and essential duty of a merchant. We will help you with this procedure by creating a receipt for your sake. For us to create these solicitations, we would require a computerized picture of your mark which will be attached on the receipt. The receipt will at that point be created and sent to the vender. The merchant will be required to physically sign the receipt, print the receipt and fasten the equivalent on the dispatch. The receipt created by WENSLINK will be joined by the dealer on the committal. Despite whatever else contained in these terms of utilization, the dealer will be exclusively subject for any risk which might be forced by tax collection experts for any error in the solicitations. 
A dealer explicitly concurs that issuing right and complete receipt is the sole and essential obligation of a merchant. Besides, merchant will guarantee that solicitations state 'Controlled by WENSLINK ' and neglecting to do as such, a dealer will be at risk to chargebacks (as appropriate). 

3.	If there should be an occurrence of any chargebacks exacted by the bank, WENSLINK will reserve the option to deduct such chargebacks from vender settlements, present and future, and a dealer's just cure will be to talk about and resolve the equivalent with the bank. A vender therefore consents to expand full co-activity in settling the chargeback questions raised by a purchaser through the bank and will give essential documentation with respect to the exchange to the total fulfillment of the bank. On the off chance that the chargeback is ruled against a vender, WENSLINK will be qualified and approved for recoup the equivalent from the merchant to its fullest degree and the bank's choice will be conclusive and official in such manner. In the occasion WENSLINK has made any overabundance installment to dealer accidentally, such abundance installments will be set-off from any future installments payable by WENSLINK  to the vender. 
4. 	WENSLINK may defer advising the installment affirmation, for example advising merchant to dispatch if WENSLINK esteems suspicious or a purchaser directs high exchange volumes to guarantee wellbeing of the exchange and exchange cost. Also, WENSLINK  may hold exchange cost and not educate vender to dispatch or transmit exchange cost to law implementation authorities (rather than discounting the equivalent to a purchaser) in line with law authorization authorities or in case of a purchaser being occupied with any type of criminal behavior. 
5. 	Merchants recognize that WENSLINK won’t be at risk for any harms, interests, claims and so on coming about because of not handling an exchange/exchange cost or any deferral in preparing an exchange/exchange value that is outside the ability to control of WENSLINK. 
6. 	WENSLINK will make installments into the financial balance given by a vender during the merchant enlistment process. Once WENSLINK has made installments into such a financial balance number, WENSLINK will be released of any/all liabilities towards the merchant and the vender will not be qualified for any cases at all. 
            </p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Consistence with Laws:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}"> 1. 	Vender will conform to all the relevant laws, including however not constrained to Food Safety and Standard Authority of India (FSSAI) and acquire every single essential permit and allows material to them. 
2. 	In case of closeout of adornments, vender will give trademark testament (as per pertinent laws) alongside the item at the hour of conveyance. Further, it will be sole duty of the vender to agree to hallmarking or other comparative arrangements relevant for the clearance of gems and WENSLINK will not be subject at all for any rebelliousness in such manner. 

3. 	In case of closeout of gems, merchant will guarantee directing of purchaser KYC as per the counteractive action of against illegal tax avoidance laws and other appropriate laws. WENSLINK thus repudiates any obligation regarding directing Buyer KYC. 
</p>

          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Item Description</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
              WENSLINK does not warrant that item depiction or other substance on the Platform is precise, finished, dependable, current, or mistake free and accept no obligation in such manner. 
            </p>
          </div>
        </div>


        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Reviews</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
              WENSLINK will reserve the privilege to investigate and review vender's records and premises/spot of business through itself or through WENSLINK endorsed outsider testing offices. Cost of such review will exclusively be borne by WENSLINK except if review reflects error in vender accounts/resistance with WENSLINK’s merchant arrangements, in which case cost of review will be borne by the dealer. 
            </p>
          </div>
        </div>

        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Break</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
              Without restricting different cures, we may restrain your action, quickly expel your data, caution different clients of your activities promptly, briefly/uncertainly suspend/end/hinder your record and additionally decline you access to the Platform in case of, including yet not constrained to, the accompanying: 
1. In the event that you rupture the ToU, protection strategy or different approaches (assuming any); 
2. In the event that we can't confirm or validate any data you give; or 
3. In the event that it is accepted that your activities may cause lawful risk for you, different clients, or us; 
We may whenever, at our sole watchfulness, reestablish suspended merchants. A merchant that has been suspended or blocked may not enlist or endeavor to enroll with us or utilize the Platform (through itself or some other element or authoritative document) in any way at all until such time that such a dealer is reestablished by us. Despite the prior, in the event that you break the ToU or different standards and arrangements, we maintain all authority to recuperate any sums due and owed by you to us and make exacting lawful move, including yet not constrained to a referral to the fitting police or different experts for starting lawbreaker or different procedures against you. 

            </p>
          </div>
        </div>

        
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Repayment </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
       You will repay and hold innocuous WENSLINK  its proprietor, licensee, associates, auxiliaries, bunch organizations (as appropriate) and their particular officials, executives, operators, and representatives from any case, request, or activities including sensible lawyers' charges made by any outsider or punishment forced due to or emerging out of your break of the ToU, protection strategy and different approaches or your infringement of any law, guidelines, guidelines or the rights (counting encroachment of licensed innovation rights) of an outsider. 
            </p>
          </div>
        </div>

        
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Trademark objection  </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
     WENSLINK regards the protected innovation of others. In the event that you feel that your trademark has been encroached, you can write to WENSLINK at info@wenslink.com.
            </p>
          </div>
        </div>
        
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Copyright Grumbling</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
     WENSLINK regard the licensed innovation of others. On the off chance that you feel that your work has been duplicated in any capacity that comprises copyright encroachment you can write to WENSLINK at info@wenslink .com.
            </p>
          </div>
        </div>
        
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Trademark, Copyright and Restriction </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
     The Website is controlled and worked by WENSLINK and items are sold by particular enlisted dealers. All material on the Platform, including pictures, representations, sound clasps, and video cuts, are ensured by copyrights, trademarks and other licensed innovation rights. You should not duplicate, imitate, republish, transfer, post, transmit, or disperse WENSLINK’s or other venders' material in any capacity, including by email or other electronic methods and whether, straightforwardly or by implication, you should not help some other individual to do as such. Without the earlier composed assent of the proprietor, alteration or utilization of the material on some other site/arranged PC condition or for any reason other than close to home, non-business use is an infringement of the copyrights, trademarks, and other restrictive rights is precluded. Any utilization for which you get any compensation, regardless of whether cash or something else, is a business use for the reasons for this provision. 
            </p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Confinement of Liability </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
     IN NO OCCASION WILL WENSLINK BE OBLIGATED FOR ANY UNIQUE, COINCIDENTAL, BACKHANDED, OR IMPORTANT HARMS OF ANY SORT REGARDING THE TOU, REGARDLESS OF WHETHER WENSLINK HAS BEEN EDUCATED AHEAD OF TIME OF THE PLAUSIBILITY OF SUCH HARMS.
            </p>
          </div>
        </div>

        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Material Law </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
     The ToU will be represented, deciphered, and translated as per the laws of India. The spot of purview will only be Guwahati. 
            </p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Jurisdictional Issues/Sale in India Only </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
     Except if generally indicated, the material on the Website is introduced exclusively with the end goal of offer in India. WENSLINK makes no portrayal that the material on the Website is suitable or accessible for use in different areas/nations other than India. The individuals who access the Website from different areas/nations other than India do as such alone activity and WENSLINK  isn't in charge of supply of items/discount for the items requested from different areas/nations other than India and consistence with neighborhood laws, if and to the degree nearby laws are pertinent. 
            </p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Get in touch with Us </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
     If you don't mind send any remarks or questions, including all enquiries not identified with trademark and copyright encroachment, on the Website to info@wenslink.com. 
            </p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Complaint Officer </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p class="a-text-left" style="font-size: 15px;white-space: pre-line;line-height: 30px;">
           As per the IT Act, 2000, and the guidelines thereunder, the name and contact subtleties of the complaint official are given underneath: 
          Mr. Ashutosh Kumar 
          WENSLINK  Private Limited  
          House No. 13A, ByeLane- 11, Milan Path, Zoo Road Tiniali, Guwahati, Dist.- Kamrup Metro
          Assam, PIN- 781024 India
          Telephone: 1800-121-3578 
          Email: sales@wenslink.com
          Time: Mon – Sat (9:00 – 18:00)

            </p>
          </div>
        </div>

        
      </div>
    </div>
  </div>
</template>

<style scoped>
/* .disabled{
  color
} */

.btn {
  background: linear-gradient(to bottom, #a8f5ff, #9bd3ff);
}

.a-checkbox.a-checkbox-fancy input,
.a-radio.a-radio-fancy input {
  top: 4px;
}
h1{
  font-size: 30px;
}
</style>