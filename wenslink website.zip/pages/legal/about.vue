<template>
  <div>
    <div class="a-box encapsulating-div container text-justify">
      <div class="a-box-inner">
        <div class="a-box header_logo_desk">
          <div class="a-box-inner">
            <div style="display: flex;
    align-items: center;">
          <a href="https://www.wenslink.com">
              <img
                src="~static/icons/logo.png"
                style="height: 75px;padding-bottom: 10px; object-fit:contain"
                class="company_logo"
              />
          </a>
              <!-- <h4 style="padding-left: 10px" class="margin-top-10">WENSLink </h4> -->
            </div>
          </div>
        </div>

        <div class="a-box seller_message_box">
          <div class="a-box-inner ">
            <h1>About WENSLINK Private Limited, ecommerce solution</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
            }">         About WENSLink- We are a startup online shopping platform providing reluctant and advanced features of Online Shopping site. Our online shopping site will provide revenue generation experience for buyers and seller. In the coming three year we will have wide networks and collection of multi brands of various categories specially  from over 100000 provincial, nationwide and global retailers . WENSLink in its promotion will be the most preferable among people’s favorite online shopping site delivering its products over more than 5000 cities and towns in India. We promise to provide our customers the delivery of products even to the interim rural or remotest areas of the country and avail regular benefits, discounts and offers to make available our products at a very reasonable rate to our valuable customers. 

            Coming forth we have come up with a very simple way of registering our Seller by filling a simple Sign up form and once the registration process is completed, you can start selling your products sitting at home or any place to the entire country’s citizen. This in turn will fulfill the sellers Entrepreneurial thoughts and desire to sell their product on WENSLink. WENSLink, have made very easy to understand and flexible process for the seller to just begin their Entrepreneurial thoughts and different advisory to help seller to become a wholesaler or retailer and once you start selling your products over WENSLink you will reach to an unamazingly height of your business and good fund raising with our help and support from manufacturer to direct customers. WENSLink have made effective plan to grow their business by fulfilling the Clients/Customers demand by simply visiting our website and log into www.wenslink.com using your mobile phones or laptops with an internet connectivity and surfing around the vast collection of products and when one have completed his/her selection you can just place the order with the details required and the products will arrive precisely to your doorstep. We do have a good numbers of Logistics partner to support our delivery on time and very rapidly.

              You will have excitement over using and shop for your favorite products at WENSLINK very efficiently using our APP., Install WENSLINK APP. available for both Android and IOS (IOS application upcoming) users, which can be downloaded from Play store and Apple Store (upcoming) respectively. The app is very easy to use and facilitate shoppers to buy products with a gust. We need to check time to time to get updated with the timely notification provided from our end so that no one misses the amazing offers and deals. Install the app now and explore the joy of shopping online from your phone or laptop!

            </p>
          </div>
      </div>
    </div>
    </div>
  </div>
</template>

<style scoped>
/* .disabled{
  color
} */

.btn {
  background: linear-gradient(to bottom, #a8f5ff, #9bd3ff);
}

.a-checkbox.a-checkbox-fancy input,
.a-radio.a-radio-fancy input {
  top: 4px;
}
h1{
  font-size: 30px;
}
p{
    font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}
</style>