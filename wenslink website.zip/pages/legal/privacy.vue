<template>
  <div>
    <div class="a-box encapsulating-div container text-justify">
      <div class="a-box-inner">
        <div class="a-box header_logo_desk">
          <div class="a-box-inner">
           <div style="display: flex;
    align-items: center;">
          <a href="https://www.wenslink.com">
              <img
                src="~static/icons/logo.png"
                style="height: 75px;padding-bottom: 10px; object-fit:contain"
                class="company_logo"
              />
          </a>
              <!-- <h4 style="padding-left: 10px" class="margin-top-10">WENSLink </h4> -->
            </div>
          </div>
        </div>

        <div class="a-box seller_message_box">
          <div class="a-box-inner">
            <h1>Privacy Policy</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">This privacy policy is an electronic record as an electronic agreement framed under the information technology act, 2000 and the standards made there under and the altered arrangements relating to electronic archives/records in different resolutions as corrected by the information technology act, 2000. This privacy policy doesn't require any physical, electronic or computerized signature.

This privacy policy is a lawfully restricting archive among you and WENSLink (the two terms characterized underneath). The details of this privacy policy will be compelling upon your acknowledgment of the equivalent (legitimately or in a roundabout way in electronic structure, by tapping on the I acknowledge tab or by utilization of the site or by different methods) and will administer the connection among you and WENSLink for your utilization of the site (characterized beneath). 

This record is distributed and will be understood as per the arrangements of the information technology (sensible security practices and systems and delicate individual information of data) rules, 2011 under information technology act, 2000; that require distributing of the protection approach for accumulation, use, stockpiling and move of touchy individual information or data. 

If it's not too much trouble perused this privacy policy cautiously. By utilizing the site, you show that you comprehend, concur and agree to this privacy policy. On the off chance that you don't concur with the details of this protection strategy, kindly don't utilize this site. You therefore give your unequivocal agree or understandings to WENSLink as gave under segment 43A and area 72A of information technology act, 2000. 

By giving us your Information or by utilizing the offices given by the Website, You thusly agree to the accumulation, stockpiling, preparing and move of any or the majority of Your Personal Information and Non-Personal Information by WENSLink as determined under this Privacy Policy. You further concur that such accumulation, use, stockpiling and move of Your Information will not make any misfortune or improper increase you or some other individual.

WENSLink Private Limited and its backups and offshoots and Associate Companies (separately and additionally by and large, “WENSLink”) is/are worried about the security of the information and data of clients (counting merchants and purchasers/clients whether enlisted or non-enrolled) getting to, offering, selling or obtaining items or administrations on WENSLink’s sites, versatile destinations or portable applications ("Website") on the Website and generally working with WENSLink. "Partner Companies" here will have a similar significance as credited in Companies Act, 2013. 

The expressions "We"/"Us"/"Our" independently and all in all allude to every substance being a piece of the meaning of WENSLink and the expressions "You"/"Your"/"Yourself" allude to the clients. This Privacy Policy is an agreement among You and the particular WENSLink substance whose Website You use or access or You generally manage. This Privacy Policy will be perused together with the separate Terms of Use or different terms and state of the individual WENSLink element and its particular Website or nature of business of the Website.
</p>
          </div>
        </div>

        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>WENSLink has given this Privacy Policy to acclimate you with:</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">• The kind of information or data that You share with or give to WENSLink and that WENSLink gathers from You; 

•	The reason for gathering of such information or data from You; 

•	WENSLink’s data security practices and approaches; and 

•	WENSLink’s arrangement on sharing or moving Your information or data with outsiders. This Privacy Policy might be corrected/refreshed every once in a while. After changing/refreshing the Privacy Policy, we will as needs be revise the date above. We propose that you consistently check this Privacy Policy to advise yourself of any updates. Your proceeded with utilization of Website or arrangement of information or data from that point will suggest Your unequivocal acknowledgment of such updates to this Privacy Policy. 

•	Information gathered and capacity of such Information: The "Data" (which will likewise incorporate information) given by You to WENSLink or gathered from You by WENSLink may comprise of "Individual Information" and "Non-Personal Information". 

•	Personal Information: Individual Information will be Information gathered that can be utilized to extraordinarily recognize or reach You. Individual Information for the motivations behind this Privacy Policy will incorporate, however not be constrained to: 

•	Your client name alongside Your secret word, 
•	Your name, 
•	Your address, 
•	Your phone number, 
•	Your email address or other contact data, 
•	Your date of birth, 
•	Your sexual orientation, 
•	Information in regards to your exchanges on the Website, (counting deals or buy history), 
•	Your budgetary data, for example, financial balance data or Visa or charge card or other installment instrument subtleties including OTP, 
•	Internet Protocol address, 
•	Any different things of 'delicate individual information or data' in that capacity term is characterized under the Information Technology (Reasonable Security Practices And Procedures And Sensitive Personal Data Of Information) Rules, 2011 ordered under the Information Technology Act, 2000; 
•	Identification code of your specialized gadget which You use to get to the Website or generally manage any WENSLink element, 
•	Any other Information that You give during Your enrollment procedure, assuming any, on the Website. Such Personal Information might be gathered in different manners including over the span of You:
•	Registering as a client on the Website, 
•	Registering as a merchant on the Website, 
•	Availing certain administrations offered on the Website. Such occasions incorporate yet are not restricted to making an idea available to be purchased, online buy, taking an interest in any online overview or challenge, speaking with WENSLink’s client care by telephone, email or generally or posting client audits on the things accessible on the Website, or 
•	Otherwise working together on the Website or generally managing any WENSLink substance. We may get Personal data about you from outsiders, for example, web based life administrations, economically accessible sources and colleagues. In the event that you get to Website through a web based life administration or interface an assistance on Website to an online networking administration, the data we gather may incorporate your client name related with that web based life administration, any data or substance the internet based life administration has the option to impart to us, for example, your profile picture, email address or companions list, and any data you have made open regarding that web based life administration. When you get to the Website or generally manage any WENSLink substance through internet based life administrations or when you associate any Website to web based life administrations, you are approving WENSLink to gather, store, and use and hold such data and substance as per this Privacy Policy. 

•	Non-Personal Information: WENSLink may likewise gather data other than Personal Information from You through the Website when You visit and/or utilize the Website. Such data might be put away in server logs. This Non-Personal Information would not help WENSLink to recognize You by and by. This Non-Personal Information may include: 
•	Your geographic area, 
•	Details of Your telecom specialist co-op or web access supplier, 
•	The kind of program (Internet Explorer, Firefox, Opera, Google Chrome and so on.), 
•	The working arrangement of Your framework, gadget and the Website You last visited before visiting the Website, 
•	The span of Your stay on the Website is additionally put away in the session alongside the date and time of Your entrance, Non-Personal Information is gathered through different ways such using treats. WENSLink may store impermanent or lasting 'treats' on Your PC. You can delete or hinder these treats from Your PC. You can design Your PC's program to caution You when we endeavor to send You a treat with an alternative to acknowledge or decline the treat. On the off chance that You have turned treats off, You might be kept from utilizing certain highlights of the Website. 

•	Ads: WENSLink may utilize outsider specialist co-ops to serve advertisements for WENSLink’s benefit over the web and once in a while on the Website. They may gather Non-Personal Information about Your visits to the Website, and Your association with our items and administrations on the Website. Kindly note that Personal Information and Non Personal Information might be dealt with diversely according to this Privacy Policy.


</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* .disabled{
  color
} */

.btn {
  background: linear-gradient(to bottom, #a8f5ff, #9bd3ff);
}

.a-checkbox.a-checkbox-fancy input,
.a-radio.a-radio-fancy input {
  top: 4px;
}
h1{
  font-size: 30px;
}
p{
    font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}
</style>