<template>
  <div>
    <div class="a-box encapsulating-div container text-justify">
      <div class="a-box-inner">
        <div class="a-box header_logo_desk">
          <div class="a-box-inner">
           <div style="display: flex;
    align-items: center;">
          <a href="https://www.wenslink.com">
              <img
                src="~static/icons/logo.png"
                style="height: 75px;padding-bottom: 10px; object-fit:contain"
                class="company_logo"
              />
          </a>
              <!-- <h4 style="padding-left: 10px" class="margin-top-10">WENSLink </h4> -->
            </div>
          </div>
        </div>

        <div class="a-box seller_message_box">
          <div class="a-box-inner">
            <h1>Return & cancellation policy</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">Limited time wears is promised to move in the direction of client's entertainment guided by moral strategic approaches. Premium imprints are pursued to have clients a huge internet printing background.

Our responsibility to client's delight guideline out the choices to return orders. At promotional wears items are tweaked to coordinate the client's particular without a hairline deviation.

In any case, this doesn't keep us from offering best of the administrations to our customer, and you can contact our client care number for all you questions and will give you the most appropriate arrangement.

Aside from quality and best costs offered at Promotional wears, Timeliness is similarly the same one of the significant benefactors towards our initiative. We progress in the direction of in time instead of on-time conveyance. We start our work when determinations are gotten from the client to ensure items get conveyed at most punctual.

Chance to drop the request is accessible till we have not begun the preparing. What's more, if a request gets dropped before preparing, all things considered, the sum might be discounted to the client. Our client service group is consistently there to control you on requests scratch-off. Don't hesitate to connect for nitty gritty data.
</p>
          </div>
        </div>

        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Limited time wears request wiping out strategy</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">* You are mentioned to quickly email at <a href="mailto:sales@wenslink.com">sales@wenslink.com</a> alongside your request number for any abrogations to be made.

* Your requests can likewise be dropped if Promotional wears group finds your instalments have not been gotten.

* Non receipt of Payment on the off chance that the instalment for the request isn't made Promotional wears will naturally drop the request. An email warning is sent to you when we drop the request.

</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* .disabled{
  color
} */

.btn {
  background: linear-gradient(to bottom, #a8f5ff, #9bd3ff);
}

.a-checkbox.a-checkbox-fancy input,
.a-radio.a-radio-fancy input {
  top: 4px;
}
h1{
  font-size: 30px;
}
p{
    font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}
</style>