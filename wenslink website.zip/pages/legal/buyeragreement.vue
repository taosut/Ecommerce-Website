<template>
  <div>
    <div class="a-box encapsulating-div container text-justify">
      <div class="a-box-inner">
        <div class="a-box header_logo_desk">
          <div class="a-box-inner">
           <div style="display: flex;
    align-items: center;">
          <a href="https://www.wenslink.com">
              <img
                src="~static/icons/logo.png"
                style="height: 75px;padding-bottom: 10px; object-fit:contain"
                class="company_logo"
              />
          </a>
              <!-- <h4 style="padding-left: 10px" class="margin-top-10">WENSLink </h4> -->
            </div>
          </div>
        </div>

        <div class="a-box seller_message_box">
          <div class="a-box-inner">
            <h1 class="text-center">Buyers Agreement</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">WENSLINK is the most gotten the opportunity to electronic business site among the Indian buyer. Or on the other hand perhaps preferring to continue to buy things in the market, purchaser need to organize on the web and if they don't believe that it's fitting, by then they have a decision of getting substitution. With spectacular offers and straightforward availability of the things the electronic shopping is getting progressively standard among the clients who approach web and especially for the individual who don't have chance to continue to buy the things from the market. Everyone recognizes to the terms and conditions given by the site, anyway no one attempts to encounter it. We ought to evaluate the terms and conditions of a part of the online retail areas. 
</p>
          </div>
        </div>

        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Stage for Transaction and Communication: </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left text-justify" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">WENSLINK in the start of its methodology figures out what WENSLINK truly is. WENSLINK terms itself as a Website rather a market where Users use to meet and work together with one another for their trades. WENSLINK dismisses all of the liabilities by showing that WENSLINK isn't and can't be a social affair to or control in any capacity any trade between the Website's Users. 

</p>
          </div>
        </div>
        </div>

        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Noteworthy terms and conditions: </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left text-justify" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">Agreement: All business/definitive terms are offered by and assented to among Buyers and Sellers alone. WENSLINK doesn't have any control or doesn't choose or provoke or at all remember itself for the offering or affirmation of such business/lawfully restricting terms between the Buyers and Sellers. 
Depiction: WENSLINK doesn't make any depiction or Warranty as to specifics, (for instance, quality, regard, attractiveness, etc) of the things or organization's proposed to be sold or offered to be sold or obtained on the Website. WENSLINK doesn't positively or explicitly support or grasp the arrangement or purchase of any things or organizations on the Website. WENSLINK recognizes no hazard for any bumbles or oversights, paying little respect to whether to assist itself or untouchables. 
Burst of Contract: WENSLINK isn't accountable for any non-execution or break of any understanding went into among Buyers and Sellers. WENSLINK can't and doesn't guarantee that the concerned Buyers or conceivably Sellers will play out any trade shut on the Website. WENSLINK won't and isn't required to intervene or resolve any inquiry or distinction among Buyers and Sellers. 

Assurance: WENSLINK doesn't make any depiction or assurance concerning the thing focal points, (for instance, legitimate title, money related sufficiency, character, etc.) of any of its Users. WENSLINK urges to self-sufficiently check the bonafides of a particular. 
Right, Title or Interest over thing: WENSLINK doesn't hold any right, title or interest, nor have any responsibilities or liabilities in respect of any understandings between buyers and sellers. WENSLINK doesn't expect any risk for unacceptable or delayed execution of organizations or damages or deferrals on account of things which are out of stock, difficult to reach or place in an IOU (I owe you) for. 
Bipartite contract: WENSLINK is simply giving a phase to correspondence and it is agreed that the understanding accessible to be bought of any of the things or organizations will be a cautiously included between both the Seller and the Buyer. 
Obstacle of Liability: WENSLINK won't be subject in any phenomenal, inadvertent, quick or significant damages in relationship with terms of use, paying little mind to whether the concerned customer has instructed early about the likelihood of damages. 
Portion: While benefitting any of the portion methodology/s available on the Website, WENSLINK won't be careful or anticipate any hazard, at all in respect of any mishap or mischief developing genuinely or in an indirect manner by virtue of: 
1.	Lack of endorsement for any trade/s, or 
2.	Exceeding beyond what many would consider possible generally agreed by you and between "Bank/s", or 
3.	Any portion issues rising out of the trade, or 
4.	Decline of trade for some other explanation/s 


</p>
          </div>
          <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Objection official</h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left text-justify" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">According to Information Technology Act 2000 and rules made there under, the name and contact nuances of the Grievance Officer are given underneath: 
Mr. Ashutosh Kumar 
WENSLINK Private Limited 
House No. 13A, ByeLane-11, Milan Path 
Zoo Road Tiniali, Guwahati 
Dist.- Kamrup Metro 
Assam, PIN-781024 IN 
Email: sales@wenslink.com 
Time: Mon – Sat (9:00 – 18:00) 
 

</p>
          </div>
        </div>
        <div class="a-box seller_message_box mt-5">
          <div class="a-box-inner">
            <h1>Discussions (Resolutions) Policy </h1>
          </div>
        </div>

        <div class="a-box noBorder pv_box" role="form">
          <div class="a-box-inner">
            <p
              class="a-text-left text-justify" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}">At WENSLINK, has a Dispute Resolution process to decide inquiries among Buyers and Sellers. 
Buyer Protection Program 
Conditions where Buyer Protection Program Works: 
1.	In occurrence of a challenge where the Seller can't give a rebate or a substitution, WENSLINK will adequately advance toward landing at an objectives. 
2.	The Buyer Protection Program covers Buyers who can't viably resolve their inquiry with the Seller or are not satisfied the objectives given by the Seller. 
3.	The Buyer can write to sales@wenslink.com if the issue with the Seller isn't settled. WENSLINK's Customer Support gathering will research the case to check for possible intimidation and if the Buyer has been boycotted/thwarted from making purchases on the Website. Basically resulting to affirming these convictions, an inquiry can be enrolled. 

4.	In appropriate method for objectives, WENSLINK's Customer Support Team will energize a telephone call including the Seller and the Buyer. 
5.	When a discussion has been raised, WENSLINK may give both the get-togethers access to each other's Display Names, contact nuances including email areas and various nuances identifying with the inquiry. Buyers and Sellers are subject to indisputable consent from WENSLINK for settling the challenge. 
If you are a buyer, by then you are obligated to following restrictions: 
1.	There is an obstacle time of 60 days in which you have to record the complaint. 
2.	The starting step which a buyer should take is contact the seller to decide the discussion. If the Buyer doesn't get notice from the Seller or can't resolve the issue with the Seller considerably after contact, a discussion can be raised with WENSLINK by forming an email to sales@wenslink.com 
3.	Buyers are not equipped for brief markdown of money or substitution of the thing. WENSLINK will be first checking the challenge and will process the cases that are real and authentic. 
4.	Claims related to 'Buyer grievances (for instance events where things are acquired by the Buyer by mistake or where the Buyer changes his/her mind as for the thing got by him) won't be locked in through this program. 
5.	(Disclaimer) don't begin invalid or bogus assurance or don't give inadequate or appealing information considering the way that WENSLINK claims power to begin normal and furthermore criminal proceeding against you in these cases. 
6.	If there is a deferral in shipment or movement of the thing by merchant then you can't record a dissent or connect any case from WENSLINK through this framework.
 

</p>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* .disabled{
  color
} */

.btn {
  background: linear-gradient(to bottom, #a8f5ff, #9bd3ff);
}

.a-checkbox.a-checkbox-fancy input,
.a-radio.a-radio-fancy input {
  top: 4px;
}
h1{
        margin-bottom: 1rem!important;
        font-size: 30px;
}
p{
    font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}
</style>