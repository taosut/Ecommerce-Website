<template>
  <div>
    <div class="a-box encapsulating-div container text-justify">
      <div class="a-box-inner">
        <div class="a-box header_logo_desk">
          <div class="a-box-inner">
            <div style="display: flex;
    align-items: center;">
          <a href="https://www.wenslink.com">
              <img
                src="~static/icons/logo.png"
                style="height: 75px;padding-bottom: 10px; object-fit:contain"
                class="company_logo"
              />
          </a>
              <!-- <h4 style="padding-left: 10px" class="margin-top-10">WENSLink </h4> -->
            </div>
          </div>
        </div>

        <div class="a-box seller_message_box">
          <div class="a-box-inner">
            <h1>Disclaimer for WENSLINK Pvt. Ltd.</h1> 
    <p>On the off chance that you require any more data or have any inquiries concerning our site's disclaimer, if it's not too much trouble don't hesitate to get in touch with us by email at info@wenslink.com </p>
            
          </div>
        </div>

        <div class="a-box noBorder pv_box mt-5" role="form">
          <div class="a-box-inner">
              <h1>Disclaimers for www.wenslink.com </h1>
            <p
              class="a-text-left" style="font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
            }">         
                All the data on this site - https://wenslink.com - is distributed in compliance with common decency and for general data reason as it were. www.wenslink.com doesn't make any guarantees about the culmination, dependability and exactness of this data. Any move you make upon the data you find on this site (www.wenslink.com), is carefully at your own hazard. www.wenslink.com won't be at risk for any misfortunes and additionally harms regarding the utilization of our site. 
From our site, you can visit different sites by following hyperlinks to such outside locales. While we endeavor to give just quality connects to helpful and moral sites, we have no influence over the substance and nature of these destinations. These connections to different sites don't suggest a proposal for all the substance found on these destinations. Site proprietors and substance may change without see and may happen before we have the chance to evacuate a connection which may have turned sour'. 
It would be ideal if you be likewise mindful that when you leave our site, different locales may have diverse security arrangements and terms which are outside our ability to control. If it's not too much trouble make certain to check the Privacy Policies of these locales just as their "Terms of Service" before taking part in any business or transferring any data. 

            </p>
          </div>
          <div class="a-box-inner mt-5">
              <h1>Disclaimers for www.wenslink.com </h1>
            <p
              class="a-text-left" style="font-size: 15px;text-align:justify
    white-space: pre-line;
    line-height: 30px;
            }">         
                All the data on this site - https://wenslink.com - is distributed in compliance with common decency and for general data reason as it were. www.wenslink.com doesn't make any guarantees about the culmination, dependability and exactness of this data. Any move you make upon the data you find on this site (www.wenslink.com), is carefully at your own hazard. www.wenslink.com won't be at risk for any misfortunes and additionally harms regarding the utilization of our site. 
From our site, you can visit different sites by following hyperlinks to such outside locales. While we endeavor to give just quality connects to helpful and moral sites, we have no influence over the substance and nature of these destinations. These connections to different sites don't suggest a proposal for all the substance found on these destinations. Site proprietors and substance may change without see and may happen before we have the chance to evacuate a connection which may have turned sour'. 
It would be ideal if you be likewise mindful that when you leave our site, different locales may have diverse security arrangements and terms which are outside our ability to control. If it's not too much trouble make certain to check the Privacy Policies of these locales just as their "Terms of Service" before taking part in any business or transferring any data. 

            </p>
          </div>
          <div class="a-box-inner mt-5">
              <h1>Assent </h1>
            <p
              class="a-text-left" style="font-size: 15px;text-align:justify
    white-space: pre-line;
    line-height: 30px;
            }">         
                By utilizing our site, you therefore agree to our disclaimer and consent to its terms. 

            </p>
          </div>
          <div class="a-box-inner mt-5">
              <h1>Update </h1>
            <p
              class="a-text-left" style="font-size: 15px;text-align:justify
    white-space: pre-line;
    line-height: 30px;
            }">         
                Should we update, revise or roll out any improvements to this archive, those progressions will be conspicuously posted here.

            </p>
          </div>
      </div>
    </div>
    </div>
  </div>
</template>

<style scoped>
/* .disabled{
  color
} */

.btn {
  background: linear-gradient(to bottom, #a8f5ff, #9bd3ff);
}

.a-checkbox.a-checkbox-fancy input,
.a-radio.a-radio-fancy input {
  top: 4px;
}
h1{
  font-size: 30px;
}
p{
    font-size: 15px;
    white-space: pre-line;
    line-height: 30px;
}
</style>