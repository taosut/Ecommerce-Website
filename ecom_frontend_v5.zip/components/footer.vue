
<template>
 <footer class="d-flex mt-4 bg-custom1">
            <div class="container pt-5 pb-5">
              <div class="row">
                <div class="col">
                  <div style="font-size: 22px">
                    Logo
                  </div>
                  <ul class="list-unstyled">
                    <li class="mb-1">Lorem, ipsum dolor sit amet</li>
                    <li class="mb-1">Lorem, ipsum dolor sit amet</li>
                    <li class="mb-1">Lorem, ipsum dolor sit amet</li>
                    <li class="mb-1">Lorem, ipsum dolor sit amet</li>
                  </ul>
                </div>
                <div class="col">
                  <p class="text-secondary mb-1 my-text-custom2">Information</p>
                  <p class="text-secondary mb-1 my-text-custom3">Won Auctions</p>
                  <p class="text-secondary mb-1 my-text-custom3">Active Bids</p>
                  <p class="text-secondary mb-1 my-text-custom3">Account Bids</p>
                  <p class="text-secondary mb-1 my-text-custom3">
                    Terms & Conditions
                  </p>
                  <p class="text-secondary mb-1 my-text-custom3">Privacy policy</p>
                </div>
                <div class="col">
                  <p class="text-secondary my-text-custom2">About XYZ</p>
                  <p class="text-justify small">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                    deserunt perferendis facilis autem, quod voluptatibus magnam
                    molestiae minima impedit quia aut beatae reiciendis eveniet
                    laudantium aspernatur aliquid soluta unde qui?
                  </p>
                </div>
                <div class="col">
                  Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                </div>
              </div>
            </div>
          </footer>
</template>
<style scoped>
.my-text-custom2 {
        font-size: 18px;
        font-weight: bold;
      }
.my-text-custom3 {
        font-size: 15px;
      }
.bg-custom1 {
        background-color: #e6e6e6;
      }
</style>