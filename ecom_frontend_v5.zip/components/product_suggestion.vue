<template>
  <div>
          <h4 class="underline">
            <span style="font-size: 18px">Cart</span>
          </h4>

          <!-- loop cart content here -->
          <div
            class="border w-100 mt-4 d-flex align-items-center container"
            style="height: 80px; position: relative;"
          >
            <!-- add a close button here -->

            <img
              src="~static/icons/close.svg"
              style="width: 10px;height: 10px;object-fit: cover;border-radius: 50%;position: absolute; top: 10px; right: 10px"
            />

            <!-- end add a close button here -->

            <img
              src="~static/images/iPhone-XR-Lock-screen-notfifications-hidden-Face-ID.jpg"
              style="width: 50px;height: 50px;object-fit: cover;border-radius: 50%"
            />

            <div class="d-flex flex-column ml-3">
              <p class="no-mar small-font bold">iPhone XR</p>
              <p class="no-mar small-font">2 x $ 150.00</p>
            </div>
          </div>
          <!-- end loop cart content -->
          <!-- loop cart content here -->
          <div
            class="border w-100 mt-4 d-flex align-items-center container"
            style="height: 80px; position: relative;"
          >
            <!-- add a close button here -->

            <img
              src="~static/icons/close.svg"
              style="width: 10px;height: 10px;object-fit: cover;border-radius: 50%;position: absolute; top: 10px; right: 10px"
            />

            <!-- end add a close button here -->

            <img
              src="~static/images/iPhone-XR-Lock-screen-notfifications-hidden-Face-ID.jpg"
              style="width: 50px;height: 50px;object-fit: cover;border-radius: 50%"
            />

            <div class="d-flex flex-column ml-3">
              <p class="no-mar small-font bold">iPhone XR</p>
              <p class="no-mar small-font">2 x $ 150.00</p>
            </div>
          </div>
          <!-- end loop cart content -->

          <hr />

          <div class="d-flex justify-content-center">
            <p class="no-mar bold">Subtotal: $300.00</p>
          </div>

          <hr />

          <div class="d-flex">
            <button class="d-flex btn btn-outline-secondary rounded-pill mr-3">View Cart</button>
            <button class="d-flex btn btn-outline-secondary rounded-pill">Checkout</button>
          </div>

          <h4 class="underline mt-4">
            <span style="font-size: 18px">Products</span>
          </h4>

          <div>
            <!-- loop here for products -->

            <div 
              v-for="p in ongoingAuction.slice(0, 5)"
              :key="p.id">
            <div @click="goToProducts(p.product_info['id'])"
              class="w-100 mt-2 d-flex align-items-center justify-content-between container pointer"
              style="height: 80px; position: relative;"
            >
              <div class="d-flex flex-column">
                <p class="no-mar bold clamp2" style="font-size:14px;white-space: pre;">{{p.product_info['product_name']}}</p>
                <div class="d-flex">
                  <p class="small-font productPrice mr-3 strikethrough">Price: $ {{p.product_info['price']}}</p>
                  <p class="small-font productPrice discountedPrice">$ {{p.product_info['discount']}}</p>
                </div>
                <div class="d-flex">
                  <div class="p-0 col-lg-12">
                    <div class="star-rating">
                      <span class="fa fa-star-o" data-rating="1"></span>
                      <span class="fa fa-star-o" data-rating="2"></span>
                      <span class="fa fa-star-o" data-rating="3"></span>
                      <span class="fa fa-star-o" data-rating="4"></span>
                      <span class="fa fa-star-o" data-rating="5"></span>
                      <input type="hidden" name="whatever1" class="rating-value" value="2.56" />
                    </div>
                  </div>
                </div>
              </div>

              <img
                 :src='"http://127.0.0.1:8000/media/products/" + p.product_info["images"][0]'
                style="width: 50px;height: 50px;object-fit: contain;"
              />
            </div>
            <hr class="no-mar" />
            </div>

            <!-- end loop here for products -->
          </div>
          </div>
</template>
<script>
export default {
  data: () => ({
    ongoingAuction: []
  }),

  mounted() {
    this.getAllOngoingAuction()
  },
  methods: {
    getAllOngoingAuction: function() {
      console.log('sdsdsd')
      this.$store.dispatch('getAllOngoingAuction').then(res => {
        console.log(res)
        this.ongoingAuction = JSON.parse(JSON.stringify(res.data))

        this.ongoingAuction.filter(
          v => (v.product_info.images = JSON.parse(v.product_info.images))
        )
      })
    },
    goToProducts: function(id) {
      
      localStorage.setItem("single_product", id)

      console.log(id)
    }
  }
}
</script>