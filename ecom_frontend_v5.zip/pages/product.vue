<template>
  <div>
    <div style="background-color:#dcdcdc;color:DodgerBlue;padding:20px;" align="center">
      <h4 class="no-mar" style="font-weight: bold">SHOP</h4>
      <p class="no-mar">Home / {{product.subcategory['name']}} / {{product.brand['name']}}</p>
    </div>
    <div class="container mt-5 mb-5">
      <div class="row">
        <!--
        *
        *
        *

        Product Container 
        
        *
        *
        *
  
        -->

        <div class="col-lg-8 col-md-12">
          <div class="row pr-5">
            <!-- image container  -->

            <div class="col-md-6 text-center mb-5">
              <img
                :src="'http://127.0.0.1:8000/media/products/' + images[0]"
                style="width: 300px;height: 300px;object-fit: contain;"
              />
            </div>

            <!-- end image container  -->

            <div class="col-md-6 col-sm-12">
              <!-- product description  -->

              <h3 class="bold clamp2">{{ product.product_name}}</h3>

              <p class="text-primary bold mb-3">${{ product.price}}</p>

              <!-- end product description  -->

              <!-- secondary action  -->

              <div class="d-flex align-items-center bid-actions">
                <!-- <input
                  class="mr-3 text-center"
                  type="text"
                  value="1"
                  style="width:30px;height:30px"
                />-->
                <button class="d-flex btn btn-primary rounded-pill mr-3" style="white-space:nowrap">
                  Add to Cart
                  <img
                    src="a.jpg"
                    style="width: 20px;height: 20px;object-fit: contain;margin-left: 5px"
                  />
                </button>
                <button class="d-flex btn btn-primary rounded-pill">
                  Bid Now
                  <img
                    src="a.jpg"
                    style="width: 20px;height: 20px;object-fit: contain;margin-left: 5px"
                  />
                </button>
              </div>

              <!-- end secondary action  -->

              <hr />

              <!-- category and tag -->

              <div class="d-flex">
                <p class="mr-3">
                  Category:
                  <a class="bold" href="#">{{ product.category['name']}}</a>
                </p>
                <p class>
                  Sub Category:
                  <a class="bold" href="#">{{ product.subcategory['name']}}</a>
                </p>
              </div>

              <!-- end category and tag -->

              <!-- timer -->

              <div class="d-flex mb-3">
                <p class="no-mar">
                  <span v-if="auction_status == 1">Time Left</span>
                  <span v-if="auction_status == 0">Auction will begin in</span>
                  {{auction_timer.days}}D:
                  <span>{{auction_timer.hours}}H:{{auction_timer.minute}}M : {{auction_timer.second}} S</span>
                </p>
              </div>

              <!-- end timer -->

              <!-- Biding Input -->

              <div class="mb-3">
                <label for="basic-url" class="mb-1">Place a Bid</label>
                <label for="basic-url" class="float-right mb-1">
                  <a href="#">Autobid</a>
                </label>
                <div class="input-group">
                  <input type="text" class="form-control" id="bid" aria-describedby="basic-addon3" />
                </div>
                <label for="basic-url" class="small-font">Minimum Bid: ${{auction_data.min_bid}}</label>
                <label for="basic-url" class="float-right small-font">0 Bids</label>
              </div>

              <!-- end Biding Input -->

              <!-- Primary actions -->

              <div class="d-flex actions justify-content-between">
                <button
                  :disabled="auction_status == 0"
                  @click="createBid"
                  class="btn btn-primary rounded mr-3"
                >Place Bid</button>
                <!-- <button class="btn btn-warning text-white rounded">Buy Out for $300</button> -->
              </div>

              <!-- end Primary actions -->
            </div>
          </div>

          <div class="row mt-5">
            <div class="col-md-12">
              <div id="exTab3">
                <ul class="nav nav-pills">
                  <li class="nav-link active first_tab" @click="desc('first_tab')">
                    <p data-toggle="tab">Description</p>
                  </li>
                  <li class="nav-link second_tab" @click="desc('second_tab')">
                    <p   data-toggle="tab">Review (0)</p>
                  </li>
                  <li class="nav-link third_tab" @click="desc('third_tab')" >
                    <p data-toggle="tab">Bidding</p>
                  </li>
                </ul>

                <div class="tab-content clearfix" style="height: 100%;min-height: 300px">
                  <div class="tab-pane active container first_tab">
                    <div class="row mt-5 mb-3">
                      <div class="col-md-3">
                        <img
                          :src="'http://127.0.0.1:8000/media/products/' + images[0]"
                          style="width: 100%;height: 100%;object-fit: contain;"
                        />
                      </div>
                      <div class="col-md-9">
                        <h5 class="bold">Description</h5>

                        <!-- Description Text here -->

                        <p style>{{ product.description}}</p>

                        <!-- end Description Text here -->
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane container second_tab">
                    <div class="mt-3 mb-3">
                      <!-- Reviews -->

                      <h5 class="bold">Reviews</h5>

                      <p>There are no reviews yet</p>

                      <p>Your rating</p>

                      <!-- need a rating system here -->

                      <div class="form-group">
                        <label for="review">Your Review *</label>
                        <textarea class="form-control"></textarea>
                      </div>

                      <div class="form-group">
                        <label for="review">Name *</label>
                        <input class="form-control" />
                      </div>

                      <div class="form-group">
                        <label for="review">Email *</label>
                        <input class="form-control" />
                      </div>

                      <button class="btn btn-primary rounded">Submit</button>

                      <!-- end Reviews -->
                    </div>
                  </div>
                  <div class="tab-pane container third_tab">
                    <div class="mt-3 mb-3">
                      <!-- Reviews -->

                      <div v-if="bidding_list.length == 0">
                        <h5 class="bold">No Bids Yet</h5>
                      </div>

                      <h5 class="bold">Bidding List</h5>
                      
                      <div v-if="bidding_list.length > 0">
                        <div v-for="p in bidding_list" :key="p.id">
                          <div style="display:flex;justify-content:space-between"><h5>{{p.user_id['email']}}</h5>
                          <p>$ {{p.price}}</p>
                          </div>
                          <p>{{p.created_date.split("T")[0]}} {{p.created_date.split("T")[1].split(":")[0]}}:{{p.created_date.split("T")[1].split(":")[1]}}</p>
                        </div>
                      </div>


                      <!-- end Reviews -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!--
        *
        *
        *

        Cart and Right Side Container 
        
        *
        *
        *
  
        -->

        <div class="col-lg-4 col-md-12">
          <productsuggestion />
        </div>
      </div>

      <h4 class="underline mt-4">
        <span style="font-size: 18px">Related Products</span>
      </h4>

      <div class="row">
        <!-- loop here -->

        <div class="col-6 col-md-4 col-lg-2 col-sm-4 text-center mt-4">
          <div>
            <img src="a.jpg" style="width: 100%;height: 150px;object-fit: contain;" />
          </div>
          <div>
            <p class="bold productPrice mb-1 mt-2">Leather Case</p>
            <p class="small-font productPrice mb-2">Price: $ 150.00</p>
            <button
              class="d-flex btn btn-sm btn-primary align-items-center rounded-pill"
              style="margin: auto"
            >
              Add to Wishlist
              <img
                src="a.jpg"
                style="width: 10px;height: 10px;object-fit: contain;margin-left: 5px"
              />
            </button>
          </div>
        </div>

        <!-- end loop here -->

        <!-- loop here -->

        <div class="col-6 col-md-4 col-lg-2 col-sm-4 text-center mt-4">
          <div>
            <img src="a.jpg" style="width: 100%;height: 150px;object-fit: contain;" />
          </div>
          <div>
            <p class="bold productPrice mb-1 mt-2">Leather Case</p>
            <p class="small-font productPrice mb-2">Price: $ 150.00</p>
            <button
              class="d-flex btn btn-sm btn-primary align-items-center rounded-pill"
              style="margin: auto"
            >
              Add to Wishlist
              <img
                src="a.jpg"
                style="width: 10px;height: 10px;object-fit: contain;margin-left: 5px"
              />
            </button>
          </div>
        </div>

        <!-- end loop here -->

        <!-- loop here -->

        <div class="col-6 col-md-4 col-lg-2 col-sm-4 text-center mt-4">
          <div>
            <img src="a.jpg" style="width: 100%;height: 150px;object-fit: contain;" />
          </div>
          <div>
            <p class="bold productPrice mb-1 mt-2">Leather Case</p>
            <p class="small-font productPrice mb-2">Price: $ 150.00</p>
            <button
              class="d-flex btn btn-sm btn-primary align-items-center rounded-pill"
              style="margin: auto"
            >
              Add to Wishlist
              <img
                src="a.jpg"
                style="width: 10px;height: 10px;object-fit: contain;margin-left: 5px"
              />
            </button>
          </div>
        </div>

        <!-- end loop here -->

        <!-- loop here -->

        <div class="col-6 col-md-4 col-lg-2 col-sm-4 text-center mt-4">
          <div>
            <img src="a.jpg" style="width: 100%;height: 150px;object-fit: contain;" />
          </div>
          <div>
            <p class="bold productPrice mb-1 mt-2">Leather Case</p>
            <p class="small-font productPrice mb-2">Price: $ 150.00</p>
            <button
              class="d-flex btn btn-sm btn-primary align-items-center rounded-pill"
              style="margin: auto"
            >
              Add to Wishlist
              <img
                src="a.jpg"
                style="width: 10px;height: 10px;object-fit: contain;margin-left: 5px"
              />
            </button>
          </div>
        </div>

        <!-- end loop here -->

        <!-- loop here -->

        <div class="col-6 col-md-4 col-lg-2 col-sm-4 text-center mt-4">
          <div>
            <img src="a.jpg" style="width: 100%;height: 150px;object-fit: contain;" />
          </div>
          <div>
            <p class="bold productPrice mb-1 mt-2">Leather Case</p>
            <p class="small-font productPrice mb-2">Price: $ 150.00</p>
            <button
              class="d-flex btn btn-sm btn-primary align-items-center rounded-pill"
              style="margin: auto"
            >
              Add to Wishlist
              <img
                src="a.jpg"
                style="width: 10px;height: 10px;object-fit: contain;margin-left: 5px"
              />
            </button>
          </div>
        </div>

        <!-- end loop here -->

        <!-- loop here -->

        <div class="col-6 col-md-4 col-lg-2 col-sm-4 text-center mt-4">
          <div>
            <img src="a.jpg" style="width: 100%;height: 150px;object-fit: contain;" />
          </div>
          <div>
            <p class="bold productPrice mb-1 mt-2">Leather Case</p>
            <p class="small-font productPrice mb-2">Price: $ 150.00</p>
            <button
              class="d-flex btn btn-sm btn-primary align-items-center rounded-pill"
              style="margin: auto"
            >
              Add to Wishlist
              <img
                src="a.jpg"
                style="width: 10px;height: 10px;object-fit: contain;margin-left: 5px"
              />
            </button>
          </div>
        </div>

        <!-- end loop here -->
      </div>
    </div>
  </div>
</template>


<script>
import productsuggestion from '@/components/product_suggestion'

export default {
  data: () => ({
    product: {
      category: {
        name: ''
      },
      subcategory: {
        name: ''
      },
      brand: {
        name: ''
      }
    },
    images: {},
    auction_data: [],
    auction_timer: [],
    auction_status: 0,
    bidding_list: {
      user_id: ""
    }
  }),

  components: {
    productsuggestion
  },

  mounted() {
    this.$store
      .dispatch('getSingleAuction', localStorage.getItem('single_product'))
      .then(res => {
        this.auction_data = JSON.parse(JSON.stringify(res.data))

        this.product = JSON.parse(JSON.stringify(res.data.product_info))

        this.images = JSON.parse(this.product.images)

        if (
          new Date(this.auction_data.start_date).getTime() -
            new Date().getTime() >
          0
        ) {
          //auction not started yet

          this.auction_status = 0

          this.countdown(this.auction_data.start_date)
        } else {
          //auction started

          this.auction_status = 1
          this.countdown(this.auction_data.end_date)
        }

        console.log(
          this.getTimerFinalValue(
            this.auction_data.start_date,
            this.auction_data.end_date
          )
        )

        this.getBidding(this.auction_data.auction_id)


      })
  },
  methods: {
    getBidding: function(id) {


      
        this.$store
          .dispatch('getBiddingFromAuctionID', id)
          .then(res => {

             this.bidding_list = JSON.parse(JSON.stringify(res.data))

          })


    },
    createBid: function() {
      console.log(this.auction_data.auction_id)
      console.log(9)
      console.log($('#bid').val())
      console.log(this.product.id)

      var payload = new FormData()

      payload.append('auction_id', this.auction_data.auction_id)
      payload.append('product_info', this.product.id)
      payload.append('price', $('#bid').val())
      payload.append('user_id', 2)

      this.$store.dispatch('createBid', payload).then(res => {
        console.log(res)
        this.getBidding(this.auction_data.auction_id)
      })
    },
    getTimerFinalValue: function(start_date, end_date) {
      var datetime = end_date

      var datetime = new Date(datetime).getTime()
      var now = new Date(start_date).getTime()

      if (isNaN(datetime)) {
        return ''
      }

      if (datetime < now) {
        var milisec_diff = now - datetime
      } else {
        var milisec_diff = datetime - now
      }

      var days = Math.floor(milisec_diff / 1000 / 60 / (60 * 24))

      var date_diff = new Date(milisec_diff)

      return {
        days: days,
        hours: date_diff.getHours(),
        minute: date_diff.getMinutes(),
        second: date_diff.getSeconds()
      }
    },
    countdown: function(end_date) {
      var vm = this
      // Update the count down every 1 second
      var x = setInterval(function() {
        vm.auction_timer = vm.getTimerFinalValue(new Date(), end_date)
      }, 1000)
    },
    desc: function(id){

        $(".active").removeClass('active')
        $("." + id).addClass('active')
      


    }
  }
}
</script>












<style scoped>
.nav-link p {
  color: black;
  cursor: pointer;
}

/* change border radius for the tab , apply corners on top*/

#exTab3 .nav-pills > li > a {
  border-radius: 4px 4px 0 0;
}

#exTab3 .nav-pills > li.active > a {
  color: black;
}

#exTab3 .tab-content {
  background-color: #fff;
  padding: 5px 15px;
  border-top: 1px solid #c7c7c7;
}

.small-font {
  font-size: 12px;
}

.actions button {
  width: 150px;
}

.bid-actions button {
  width: 130px;
  justify-content: center;
  align-items: center;
}

a:hover {
  text-decoration: none;
  cursor: pointer;
}

p.productPrice {
  margin-bottom: 0;
}

.strikethrough {
  text-decoration: line-through;
}
.discountedPrice {
  background-color: #8bc34a;
  color: white;
  padding: 0 10px;
}
.underline span {
  position: relative;
  width: 100%;
}

@media only screen and (min-width: 768px) and (max-width: 1199px) {
  .container {
    max-width: 930px;
  }
}
input[type='text'] {
  /* width: 130px; */
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}

input[type='text']:focus {
  width: 100%;
}

html,
body {
  font-size: 14px;
  height: 100%;
  width: 100%;
}

.my-text {
  font-size: 12px;
}

.flex-container {
  display: flex;
  flex-direction: column;
}

.my-text-custom {
  font-size: 10px;
}

.bg-custom1 {
  background-color: #e6e6e6;
}

.my-text-custom2 {
  font-size: 18px;
  font-weight: bold;
}

.my-text-custom3 {
  font-size: 15px;
}

.login-section {
  padding: 20px 20px 20px;
}

.padding-10 {
  padding: 10px;
}

.padding-top-10 {
  padding-top: 10px;
}

.padding-bottom-10 {
  padding-bottom: 10px;
}

.padding-right-10 {
  padding-right: 10px;
}

.padding-left-10 {
  padding-left: 10px;
}

.no-mar {
  margin: 0 !important;
}

.no-padd {
  padding: 0 !important;
}

.myHeader p {
  margin: 0;
  font-size: 10px;
  margin-left: 10px;
}

.myborder-right .null {
  margin: 0;
  margin: 0 10px !important;
  font-size: 12px !important;
  font-weight: bold;
}

.myborder-right div {
  border-right: 1px solid #b0b0b0;
}

.ul .mydropdown {
  display: flex;
  align-items: center;
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

.nav-link p {
  color:black
}

/* li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: blue;
}

li.dropdown {
  display: inline-block;
  } */

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #f1f1f1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.bold {
  font-weight: bold;
}

#exTab3 {
  background-color: grey;
  border: 1px solid #c7c7c7;
}

.nav-pills .nav-link {
  border-radius: 0 !important;
}

.nav.nav-pills {
  top: 0px;
  height: 40px;
  background-color: #ececec;
}

.nav-link {
  border: 1px solid #c7c7c7;
  border-right: 0 !important;
  border-top: 0;
}

.nav-link:last-child {
  border: 1px solid #c7c7c7;
  border-top: 0;
  border-right: 1px solid #c7c7c7 !important;
}

.nav-link:first-child {
  border: 1px solid #c7c7c7;
  border-top: 0;
  border-left: 0 !important;
}

.nav-pills .nav-link.active,
.nav-pills .show > .nav-link {
  background-color: white;
  border: 1px solid #c7c7c7;
  border-bottom: 0;
  border-top: 0;
}

.nav-link a {
  color: black;
}

/* change border radius for the tab , apply corners on top*/

#exTab3 .nav-pills > li > a {
  border-radius: 4px 4px 0 0;
}

#exTab3 .nav-pills > li.active > a {
  color: black;
}

#exTab3 .tab-content {
  background-color: #fff;
  padding: 5px 15px;
  border-top: 1px solid #c7c7c7;
}

.small-font {
  font-size: 12px;
}

.actions button {
  width: 150px;
}

.bid-actions button {
  width: 130px;
  justify-content: center;
  align-items: center;
}

a:hover {
  text-decoration: none;
  cursor: pointer;
}

p.productPrice {
  margin-bottom: 0;
}

.strikethrough {
  text-decoration: line-through;
}
.discountedPrice {
  background-color: #8bc34a;
  color: white;
  padding: 0 10px;
}

.btn-buy {
  background-color: #fb641b;
}

@media only screen and (min-width: 768px) and (max-width: 1199px) {
  .container {
    max-width: 930px;
  }
}

button[disabled] {
  cursor: not-allowed;
  background-color: #9e9e9e;
  border-color: #9e9e9e;
}
</style>