<template>
  <div>
    <div class="container mt-5">
      <div class="row mr-3">
        <div class="col-sm-8 col-md-8">
          <div class="hero_image" style="height: 430px;">
            <img
              style="object-fit: cover; object-position:center;border-radius: 5px;"
              class="w-100 h-100"
              src="images/1.jpg"
              alt
            />
          </div>
        </div>
        <div class="col-sm-4 col-md-4">
          <div class="row h-50">
            <div class="col-sm-12 p-0">
              <div class="hero_image bg-success" style="height: 207px">
                <img
                  style="object-fit: cover; object-position: center;border-radius: 5px;"
                  src="images/2.jpeg"
                  alt
                  class="w-100 h-100"
                />
              </div>
            </div>
            <div class="col-sm-12 p-0" style="margin-top:15px">
              <div class="hero_image" style="height: 207px">
                <img
                  style="object-fit: cover; object-position: center;border-radius: 5px;"
                  src="images/3.jpeg"
                  alt
                  class="w-100 h-100"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container mt-5">
      <div class="row">
        <div class="d-flex justify-content-between w-100 container">
          <div class="relative w-100">
            <h4 class="underline w-100">
              <span style="font-size: 18px">Featured Auctions</span>
            </h4>
            <a
              style="color:#0056b3;font-size: 12px;font-weight:bold;position:absolute;right:0;bottom:20px"
            >VIEW ALL</a>
          </div>
        </div>
      </div>
      <div class="row mt-4">
        <div class="col-lg-3 col-md-6">
          <img
            src="~static/images/women-ad.jpg"
            style="object-fit: cover; width: 100%; height: 100%;"
            alt
          />
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="border">
            <div
              class="d-flex w-100 bg-error justify-content-center"
              style="font-size:17px; font-weight:bold; font-family: 'Lato',
          sans-serif; background-color:  #d44753; color: #ffffff"
            >TODAY'S DEAL</div>
            <div class="p-3">
              <div class="image-container">
                <img src="Images/4.jpeg" style="width: 100%; height: 150px; object-fit: contain" />
              </div>
              <div class="product-info text-center pb-3 pt-3">
                <h6>One piece party wear</h6>
                <p class="small-font">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum molestias
                  voluptatum quisquam ad labore explicabo dolorem eligendi
                </p>
              </div>
              <div class="d-flex topbids-actions justify-content-between">
                <button
                  class="d-flex btn button-small rounded-0 align-items-center"
                  style="margin: 0 1px"
                >
                  <img
                    src="~static/icons/favorite-heart-button (1).svg"
                    style="width: 13px;height: 13px;object-fit: contain;"
                  />
                </button>
                <button
                  class="d-flex btn rounded-0 align-items-center"
                  style="margin:  0 1px;width: 192px;height: 42px;background-color: #d44753 "
                >
                  <img
                    src="~static/icons/shopping-cart-black-shape (2).svg"
                    style="width: 15px;height: 15px;object-fit: contain;margin-right: 5px"
                  />
                  <span class="large-font" style="color:#ffffff">Add to Cart</span>
                </button>
                <button
                  class="d-flex btn button-small rounded-0 align-items-center"
                  style="margin:  0 1px"
                >
                  <img
                    src="~static/icons/auction (1).svg"
                    style="width: 13px;height: 13px;object-fit: contain;"
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="border">
            <!-- loop here-->
            <div class="col-md-12" v-for="p in ongoingAuction.slice(0, 4)" :key="p.id">
              <div class="d-flex align-items-center h-100 border-bottom pt-2 pb-2">
                <div style="width:90px; height: 90px">
                  <img
                     :src='"http://127.0.0.1:8000/media/products/" + p.product_info["images"][0]'
                    style="width:100%; height: 100%; object-fit: contain"
                    @error="setFallbackImageUrl"
                    
                  />
                </div>
                <div class="d-flex flex-column w-100 pl-2">
                  <p
                    class="m-0 clamp2"
                    style="color:  #d44753;font-size:14px"
                  >{{p.product_info['product_name']}}</p>
                  <p class="m-0" style="font-size:12px">$ {{p.product_info['price']}}</p>
                  <div class="d-flex">
                    <div>
                      <img
                        @click="addToCart(p.product_info.id)"
                        style="width:20px;height:20px"
                        src="~static/icons/shopping-cart-black-shape.svg"
                        alt
                      />
                    </div>
                    <div class="pl-3">
                      <a href>
                        <img
                          style="width:20px;height:20px"
                          src="~static/icons/auction hammer.svg"
                          alt
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- end loop here-->
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <div class="border">
            <!-- loop here-->
            <div class="col-md-12" v-for="p in ongoingAuction.slice(4 , 8)" :key="p.id">
              <div class="d-flex align-items-center h-100 border-bottom pt-2 pb-2">
                <div style="width:90px; height: 90px">
                  <a src href>
                    <img
                      :src='"http://127.0.0.1:8000/media/products/" + p.product_info["images"][0]'
                      style="width:100%; height: 100%; object-fit: contain"
                      @error="setFallbackImageUrl"
                    />
                  </a>
                </div>
                <div class="d-flex flex-column w-100 pl-2">
                  <p
                    class="m-0 clamp2"
                    style="color:  #d44753;font-size:14px"
                  >{{p.product_info['product_name']}}</p>
                  <p class="m-0" style="font-size:12px">$ {{p.product_info['price']}}</p>
                  <div class="d-flex">
                    <div>
                      <a href>
                        <img
                          style="width:20px;height:20px"
                          src="~static/icons/shopping-cart-black-shape.svg"
                          alt
                        />
                      </a>
                    </div>
                    <div class="pl-3">
                      <a href>
                        <img
                          style="width:20px;height:20px"
                          src="~static/icons/auction hammer.svg"
                          alt
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- end loop here-->
          </div>
        </div>
      </div>
    </div>
    <div class="container mt-4">
      <div class="row">
        <div class="col-sm-12 col-md-3 box-style">
          <img
            class="w-100 h-100"
            src="~static/images/NoPath - Copy (12).jpg"
            style="object-fit: contain"
            alt
          />
        </div>
        <div class="col-sm-12 col-md-3 box-style">
          <img
            class="w-100 h-100"
            src="~static/images/fashion-1031469_1920.jpg"
            style="object-fit: contain"
            alt
          />
        </div>
        <div class="col-sm-12 col-md-3 box-style">
          <img
            class="w-100 h-100"
            src="~static/images/NoPath - Copy (42).jpg"
            style="object-fit: contain"
            alt
          />
        </div>
        <div class="col-sm-12 col-md-3 box-style">
          <img
            class="w-100 h-100"
            src="~static/images/NoPath - Copy (44).jpg"
            style="object-fit: contain"
            alt
          />
        </div>
      </div>
    </div>
    <div
      class="container w-100 mt-5 d-flex justify-content-center align-items-center"
      style="height: 150px;background-color:  #d44753;font-size: 50px; color:
      #ffffff; font-weight: bold"
    >
      <p>Ads</p>
    </div>
    <div class="container mt-5">
      <div class="row" style="height: 55px">
        <div class="d-flex justify-content-between w-100 container">
          <div class="relative w-100">
            <h4 class="underline w-100">
              <span style="font-size: 18px">Featured Deals</span>
            </h4>
            <a
              style="color:#0056b3;font-size: 12px;font-weight:bold;position:absolute;right:0;bottom:20px"
            >VIEW ALL</a>
          </div>
        </div>
      </div>
      <div class="row mt-4">
        <div class="col-lg-3 col-md-6">
          <div class="border">
            <!-- loop here-->
            <div class="col-md-12" v-for="p in allProducts.slice(0,4)" :key="p.id">
              <div class="d-flex align-items-center h-100 border-bottom pt-2 pb-2">
                <div style="width:90px; height: 90px">
                  <a src href>
                    <img
                      :src='"http://127.0.0.1:8000/media/products/" + p.images[0]'
                      style="width:100%; height: 100%; object-fit: contain"
                      @error="setFallbackImageUrl"
                    />
                  </a>
                </div>
                <div class="d-flex flex-column w-100 pl-3">
                  <p class="m-0 clamp2" style="color:#81b441;">{{p.product_name}}</p>
                  <p class="m-0">Price $ {{p.price}}</p>
                  <div class="d-flex">
                    <div>
                      <a href>
                        <img
                          style="width:20px;height:20px"
                          src="~static/icons/shopping-cart-green-shape.png"
                          alt
                        />
                      </a>
                    </div>
                    <div class="pl-3">
                      <a href>
                        <img
                          style="width:20px;height:20px"
                          src="~static/icons/auction-hammer-green.svg"
                          alt
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- end loop here-->
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <div class="border">
            <!-- loop here-->
            <div class="col-md-12" v-for="p in allProducts.slice(4,8)" :key="p.id">
              <div class="d-flex align-items-center h-100 border-bottom pt-2 pb-2">
                <div style="width:90px; height: 90px">
                  <a src href>
                    <img
                      :src='"http://127.0.0.1:8000/media/products/" + p.images[0]'
                      style="width:100%; height: 100%; object-fit: contain"
                      @error="setFallbackImageUrl"
                    />
                  </a>
                </div>
                <div class="d-flex flex-column w-100 pl-3">
                  <p class="m-0 clamp2" style="color:#81b441;">{{p.product_name}}</p>
                  <p class="m-0">Price $ {{p.price}}</p>
                  <div class="d-flex">
                    <div>
                      <a href>
                        <img
                          style="width:20px;height:20px"
                          src="~static/icons/shopping-cart-green-shape.png"
                          alt
                        />
                      </a>
                    </div>
                    <div class="pl-3">
                      <a href>
                        <img
                          style="width:20px;height:20px"
                          src="~static/icons/auction-hammer-green.svg"
                          alt
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- end loop here-->

          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <div class="border">
            <div
              class="d-flex w-100 bg-error justify-content-center"
              style="font-size:17px; font-weight:bold; font-family: 'Lato',
                          sans-serif;height:30px; background-color: #81b441; color: #ffffff"
            >TODAY'S DEAL</div>
            <div class="p-3">
              <div class="image-container">
                <img
                  src="~static/images/Group 34.jpg"
                  style="width: 100%; height: 150px; object-fit: contain"
                />
              </div>
              <div class="product-info text-center pb-3 pt-3">
                <h6>Men Silk Ties</h6>
                <p class="small-font">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum molestias
                  voluptatum quisquam ad labore explicabo dolorem eligendi
                </p>
              </div>
              <div class="d-flex topbids-actions justify-content-between">
                <button
                  class="d-flex btn button-small rounded-0 align-items-center"
                  style="margin: 0 1px"
                >
                  <img
                    src="~static/icons/favorite-heart-button (1).svg"
                    style="width: 13px;height: 13px;object-fit: contain;"
                  />
                </button>
                <button
                  class="d-flex btn rounded-0 align-items-center"
                  style="margin:  0 1px;width: 192px;height: 42px;background-color:#81b441 "
                >
                  <img
                    src="~static/icons/shopping-cart-black-shape (2).svg"
                    style="width: 15px;height: 15px;object-fit: contain;margin-right: 5px"
                  />
                  <span class="large-font" style="color:#ffffff">Add to Cart</span>
                </button>
                <button
                  class="d-flex btn button-small rounded-0 align-items-center"
                  style="margin:  0 1px"
                >
                  <img
                    src="~static/icons/auction (1).svg"
                    style="width: 13px;height: 13px;object-fit: contain;"
                  />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <img
            src="~static/images/men-ad.jpg"
            style="object-fit: cover; width: 100%; height: 100%;"
            alt
          />
        </div>
      </div>
    </div>
    <!-- <div class="container-fluid mt-5" style="height: 200px">
      <img
        class="w-100 h-100"
        style="object-fit: contain"
        src="~static/images/NoPath - Copy (48).jpg"
      />
    </div>-->

    <div class="container mt-5">
      <div class="border">
        <div class="w-100 align-middle" style="border-bottom:1px solid #dee2e6 ">
          <p
            class="m-0 padding-right-10 my-text-custom2"
            style="padding: 15px 20px;border-top: 5px solid #E91E63;font-size: 20px;font-weight: bold;"
          >Live Auction</p>
        </div>

        <div class="container">
          <div class="row">
            <div class="container-fluid h-100 mb-4">
              <div class="owl-carousel products">
                <div v-for="p in ongoingAuction" :key="p.id">
                  <div class="w-100">
                    <div style="padding:15px">
                      <img
                        style="object-fit: contain"
                        class="w-100 h-100"
                       :src='"http://127.0.0.1:8000/media/products/" + p.product_info["images"][0]'
                        @error="setFallbackImageUrl"
                      />
                    </div>
                    <div class="d-flex flex-column w-100 pl-3">
                      <p class="m-0" style="color:  #d44753;">{{p.product_info['product_name']}}</p>
                      <p class="m-0">Price ${{p.product_info['price']}}</p>
                      <div class="d-flex">
                        <div>
                          <a href>
                            <img
                              style="width:20px;height:20px"
                              src="~static/icons/shopping-cart-black-shape.svg"
                              alt
                            />
                          </a>
                        </div>
                        <div class="pl-3">
                          <a href>
                            <img
                              style="width:20px;height:20px"
                              src="~static/icons/auction hammer.svg"
                              alt
                            />
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container mt-5">
      <div
        class="d-flex justify-content-between border round-0"
        style="height: 80px;background-image: linear-gradient(45deg, black, #673AB7)"
      >
        <h3 style="color:#ffffff;margin-left:20px;margin-top:17px ">Become a member</h3>

        <div>
          <button
            type="button"
            class="btn btn-danger btn-lg"
            style="width: 300px;margin-right:20px;margin-top:17px  "
          >
            <h6>Get Started Today</h6>
          </button>
        </div>
      </div>
    </div>
    <div class="container mt-5">
      <div class="row">
        <div class="d-flex justify-content-between w-100 container">
          <div class="relative w-100">
            <h4 class="underline w-100">
              <span style="font-size: 18px">Upcoming Auctions</span>
            </h4>
            <a
              style="color:#0056b3;font-size: 12px;font-weight:bold;position:absolute;right:0;bottom:20px"
            >VIEW ALL</a>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- loop here -->

        <div v-for="p in allUpcomingAuction.slice(0, 6)" :key="p.id"  class="col-6 col-md-4 col-lg-2 col-sm-4 text-center mt-4">
          <div>
            <img
              :src='"http://127.0.0.1:8000/media/products/" + p.product_info["images"][0]'
              style="width: 100%;height: 150px;object-fit: contain;"
              @error="setFallbackImageUrl"
            />
          </div>
          <div>
            <p class="bold productPrice mb-1 mt-2">{{p.product_info['product_name']}}</p>
            <p class="small-font productPrice mb-2">Price: $ {{p.product_info['price']}}</p>
            <button
              class="d-flex btn btn-sm align-items-center rounded-pill"
              style="margin: auto;background-color: #ffc300;color: #ffffff"
            >
              Add to Wishlist
              <img
                src="~static/icons/favorite-heart-button (2).svg"
                style="width: 10px;height: 10px;object-fit: contain;margin-left: 5px"
              />
            </button>
          </div>
        </div>

        <!-- end loop here -->
      </div>
    </div>

    <div
      class="mt-5"
      style="background-color: #009688; color: white;padding-top: 2rem;padding-bottom:2rem"
    >
      <div class="container">
        <h1 class="header center">
          <!-- <span class="white">Testimonials</span> -->
        </h1>
        <div class="owl-carousel testimonial">
          <div>
            <div class="testimonial-body center">
              <p class="quoteMark">
                <img src="~static/quoteMark.svg" />
              </p>

              <div class="testimony-profile flex justify-center">
                <img src="~static/testi_profile.jpg" />
              </div>

              <div class="testimony-profile flex justify-center">
                <h3 class="testimony-name">Rakesh Agarwal</h3>
              </div>

              <p class="testimony-desc">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Atque illum minus in consectetur sint! Distinctio eaque eligendi saepe delectus incidunt,
                deserunt voluptatem, sed possimus maiores, odio ipsa enim eos? Molestias.
              </p>
              <p class="quoteMark-down">
                <img src="~static/quoteMark.svg" />
              </p>
            </div>
          </div>
          <div>
            <div class="testimonial-body center">
              <p class="quoteMark">
                <img src="~static/quoteMark.svg" />
              </p>
              <div class="testimony-profile flex justify-center">
                <img src="~static/testi_profile.jpg" />
              </div>

              <div class="testimony-profile flex justify-center">
                <h3 class="testimony-name">Rakesh Agarwal</h3>
              </div>
              <p class="testimony-desc">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Atque illum minus in consectetur sint! Distinctio eaque eligendi saepe delectus incidunt,
                deserunt voluptatem, sed possimus maiores, odio ipsa enim eos? Molestias.
              </p>
              <p class="quoteMark-down">
                <img src="~static/quoteMark.svg" />
              </p>
            </div>
          </div>
          <div>
            <div class="testimonial-body center">
              <p class="quoteMark">
                <img src="~static/quoteMark.svg" />
              </p>
              <div class="testimony-profile flex justify-center">
                <img src="~static/testi_profile.jpg" />
              </div>

              <div class="testimony-profile flex justify-center">
                <h3 class="testimony-name">Rakesh Agarwal</h3>
              </div>
              <p class="testimony-desc">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Atque illum minus in consectetur sint! Distinctio eaque eligendi saepe delectus incidunt,
                deserunt voluptatem, sed possimus maiores, odio ipsa enim eos? Molestias.
              </p>
              <p class="quoteMark-down">
                <img src="~static/quoteMark.svg" />
              </p>
            </div>
          </div>
          <div>
            <div class="testimonial-body center">
              <p class="quoteMark">
                <img src="~static/quoteMark.svg" />
              </p>
              <div class="testimony-profile flex justify-center">
                <img src="~static/testi_profile.jpg" />
              </div>

              <div class="testimony-profile flex justify-center">
                <h3 class="testimony-name">Rakesh Agarwal</h3>
              </div>
              <p class="testimony-desc">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Atque illum minus in consectetur sint! Distinctio eaque eligendi saepe delectus incidunt,
                deserunt voluptatem, sed possimus maiores, odio ipsa enim eos? Molestias.
              </p>
              <p class="quoteMark-down">
                <img src="~static/quoteMark.svg" />
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container mt-5">
      <div class="row" style="height: 55px">
        <div class="d-flex justify-content-between w-100 container">
          <div class="relative w-100">
            <h4 class="underline w-100">
              <span style="font-size: 18px">Closed Auction</span>
            </h4>
            <a
              style="color:#0056b3;font-size: 12px;font-weight:bold;position:absolute;right:0;bottom:20px"
            >VIEW ALL</a>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- loop here -->

        <div
          v-for="p in allCompletedAuction"
          :key="p.id"
          class="col-6 col-md-4 col-lg-2 col-sm-4 mt-4"
        >
          <div>
            <img
              :src='"http://127.0.0.1:8000/media/products/" + p.product_info["images"][0]'
              style="width: 100%;height: 150px;object-fit: contain;"
            />
          </div>
          <div>
            <p class="bold product_name mb-1 mt-2 clamp2">{{p.product_info['product_name']}}</p>
            <p class="small-font productPrice mb-2">Price: $ {{p.product_info['price']}}</p>
            <button
              class="d-flex btn btn-sm align-items-center rounded-pill"
              style="margin: auto;background-color: #ffc300;color: #ffffff"
            >
              Add to Wishlist
              <img
                src="~static/icons/favorite-heart-button (2).svg"
                style="width: 10px;height: 10px;object-fit: contain;margin-left: 5px"
              />
            </button>
          </div>
        </div>

        <!-- end loop here -->
      </div>
    </div>
    <div class="container mt-4">
      <p class="text-center text-secondary my-text-custom2">OUR ASSOCIATES</p>
    </div>
    <div class="container mt-5 align-items-center">
      <div class="owl-carousel associates">
        <div>
          <div class="p-5">
            <img src="~static/images/benq-1.jpg" />
          </div>
        </div>
        <div>
          <div class="p-5">
            <img src="~static/images/wordmark-black-medium.jpg" />
          </div>
        </div>
        <div>
          <div class="p-5">
            <img src="~static/images/msi-3.jpg" />
          </div>
        </div>
        <div>
          <div class="p-5">
            <img src="~static/images/jquery_black-copy.jpg" />
          </div>
        </div>
        <div>
          <div class="p-5">
            <img src="~static/images/dribble_black.jpg" />
          </div>
        </div>
        <div>
          <div class="p-5">
            <img src="~static/images/wordmark-black-medium.jpg" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data: () => ({
    ongoingAuction: [
      {
        product_info: {
          id: '',
          images: []
        }
      }
    ],
    allCompletedAuction: [
      {
        product_info: {
          id: '',
          images: []
        }
      }
    ],
    allUpcomingAuction: [
      {
        product_info: {
          id: '',
          images: []
        }
      }
    ],
    allProducts: [
      {
          id: '',
          images: []
        
      }
    ]
  }),
  mounted() {
    this.getAllOngoingAuction()
    this.getAllCompletedAuction()
    this.getAllUpcomingAuction()
    this.getAllProducts()

    setTimeout(function() {
      $('.associates').owlCarousel({
        loop: true,
        nav: true,
        navText: [
          "<img class='rotate180' src='icons/arrow.svg'>",
          "<img src='icons/arrow.svg'>"
        ],
        dotsEach: true,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 3
          },
          1000: {
            items: 5
          }
        }
      })
      $('.hero-carousel, .testimonial').owlCarousel({
        loop: true,
        margin: 10,
        center: true,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1
          }
        }
      })
    }, 100)
  },
  methods: {
    getAllOngoingAuction: function() {
      console.log('sdsdsd')
      this.$store.dispatch('getAllOngoingAuction').then(res => {
        console.log(res)
        this.ongoingAuction = JSON.parse(JSON.stringify(res.data))

        this.ongoingAuction.filter(
          v => (v.product_info.images = JSON.parse(v.product_info.images))
        )

        setTimeout(function() {
          $('.products').owlCarousel({
            loop: true,
            nav: true,
            navText: [
              "<img class='rotate180' src='icons/arrow.svg'>",
              "<img src='icons/arrow.svg'>"
            ],
            dotsEach: true,
            responsive: {
              0: {
                items: 1
              },
              600: {
                items: 3
              },
              1000: {
                items: 5
              }
            }
          })
        }, 100)
      })
    },
    getAllCompletedAuction: function() {
      console.log('sdsdsd')
      this.$store.dispatch('getAllCompletedAuction').then(res => {
        console.log(res)
        this.allCompletedAuction = JSON.parse(JSON.stringify(res.data))

        this.allCompletedAuction.filter(
          v => (v.product_info.images = JSON.parse(v.product_info.images))
        )
      })
    },
    getAllUpcomingAuction: function() {
      this.$store.dispatch('getAllUpcomingAuction').then(res => {
        console.log(res)
        this.allUpcomingAuction = JSON.parse(JSON.stringify(res.data))

        this.allUpcomingAuction.filter(
          v => (v.product_info.images = JSON.parse(v.product_info.images))
        )
      })
    },
    getAllProducts: function() {
      this.$store.dispatch('allProducts').then(res => {
        console.log(res)
        this.allProducts = JSON.parse(JSON.stringify(res.data))

        this.allProducts.filter(
          v => (v.images = JSON.parse(v.images))
        )
      })
    },
    goToProducts: function(id) {
      localStorage.setItem('single_product', id)

      console.log(id)

      this.$router.push('/product')
    }
  }
}
</script>

<style scoped>
.testimony-profile img {
  height: 120px;
  border-radius: 50%;
  width: 120px;
  -o-object-fit: cover;
  object-fit: cover;
}

.testimonial-body {
  margin: auto;
  width: 50%;
  position: relative;
}

.product_name {
  font-size: 13px;
  line-height: 20px;
  height: 40px;
}

.hero_image img:hover{
  box-shadow: 0px 5px 11px #2e2c2c5c;
  transition: all 0.4s ease-in-out
}
</style>